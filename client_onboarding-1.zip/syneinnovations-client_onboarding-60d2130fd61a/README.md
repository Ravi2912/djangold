# NG-Boilerplate

Angular 6 Boilerplate Project

Includes:
- Core module ( Main Routing , Auth Login , Not found ..)
- Admin Module ( sample module with dashboard page )
- Shared Module 
- Pipes Module
 
Using UIKit as the presentation framework
