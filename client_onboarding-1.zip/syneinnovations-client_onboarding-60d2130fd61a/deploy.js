var FtpDeploy = require('ftp-deploy');
var ftpDeploy = new FtpDeploy();

var config = {
	user: "synonboarding",                   // NOTE that this was username in 1.x 
    password: "^0IYD,mRkv2.",           // optional, prompted if none given
	host: "synonboarding.tk",
	port: 21,
	localRoot: __dirname + '/dist/',
	remoteRoot: '/public_html/',
	// include: ['*', '**/*'],      // this would upload everything except dot files
	include: ['*', '**/*'],
    exclude: ['**/*.map'],     // e.g. exclude sourcemaps - ** exclude: [] if nothing to exclude **
    deleteRemote: false              // delete existing files at destination before uploading
}


//use with callback
ftpDeploy.deploy(config, function(err) {
	if (err) console.log(err)
	else console.log('finished');
});
