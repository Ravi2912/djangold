/**
 * 
 * Finlap - POC - ClientOnboarding
 * 
 */
;(function() {


  /**
   * Definition of the main app module and its dependencies
   */
  angular
    .module('ClientOnboarding', [
       'ui.router',
       'naif.base64',
       'ngAnimate', 
       'ngSanitize', 
       'ui.bootstrap',
       'ui-notification',
       'imageCropper'
    ])
    .config(config);

  // safe dependency injection
  // this prevents minification issues
  config.$inject = ['$locationProvider', '$httpProvider', '$compileProvider', '$stateProvider', '$urlRouterProvider'];

  /**
   * App routing
   *
   * You can leave it here in the config section or take it out
   * into separate file
   * 
   */
  function config($locationProvider, $httpProvider, $compileProvider, $stateProvider, $urlRouterProvider) {

    $locationProvider.html5Mode(false);

      $stateProvider
      
      // LANDING PAGE ========================================
      .state('home', {
          url: '/',
          templateUrl: 'views/landing-page.html',
          controller: 'landingPageController',
          controllerAs: 'landingPage'   
      })
     // create leads =================================
      .state('createleads', {
          url: '/createleads',
          templateUrl: 'views/create_leads.html',
          controller: 'createLeadsController',
          controllerAs: 'createLeads'  
      })
      // leads =================================
      .state('leads', {
          url: '/leads',
          templateUrl: 'views/leads.html',
          controller: 'leadsController',
          controllerAs: 'leads'  
      })
      // deferred  =================================
      .state('deferred', {
          url: '/deferred',
          templateUrl: 'views/leads.html',
          controller: 'leadsController',
          controllerAs: 'leads'  
      })
      // history  =================================
      .state('history', {
          url: '/history',
          templateUrl: 'views/leads.html',
          controller: 'leadsController',
          controllerAs: 'leads'  
      });

    //set global timeout config to 2min
    $httpProvider.defaults.timeout = 120000;
    $urlRouterProvider.otherwise('/');

    $httpProvider.interceptors.push('httpInterceptor');

  }


  
  /**
   * Run block
   */
  angular
    .module('ClientOnboarding')
    .run(run);

  run.$inject = ['$rootScope', '$location', '$state'];

  function run($rootScope, $location, $state) {
    $rootScope.$on('$locationChangeSuccess', function(evt) {
        //temp logic to manager user state - only for POC
        //Note: This need to be updated for actual application

        //if home
        if($location.$$path === "/"){
          //update the navigation and header display
          $rootScope.displayPageNavigation = false;
          $rootScope.displayPageHeader = false;
        }else{
          //update the navigation and header display
          $rootScope.displayPageHeader = true;
          //if user type not exist
          if(!$rootScope.userType){
            //navigation user back to home
            $state.go('home');
          }
          //if user is admin
          if($rootScope.userType === 'admin'){
            //display navigation
             $rootScope.displayPageNavigation = true;
          }else{
            //else hide navigation
            $rootScope.displayPageNavigation = false;
          }
        }
    });
    

  }


})();