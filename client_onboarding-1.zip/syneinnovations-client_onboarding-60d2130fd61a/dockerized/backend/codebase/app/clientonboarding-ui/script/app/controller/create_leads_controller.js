/**
 * 
 *  ClientOnboarding - Create Leads Controller
 * 
 */
;(function() {


  /**
   * Angular Dependencies: $scope, $http
     Service Dependencies: OCRData: Contain utility props and methods 
   */
  angular
    .module('ClientOnboarding')
    .controller('createLeadsController', function($scope, $http, OCRData, $state, Notification, ClientAPI){

      //hold context
      var createLeads = this;
      //default valur of active tab - OCR FLOW
      createLeads.activeTab = "UPLOAD";
      //default value of OCR Completed Status
      createLeads.OCRCompleted = false;
      //default value for allowing user to upload salary doc
      createLeads.allowSalaryUpload = false;
      //default value of OCR Form data: Final stage
      createLeads.ocrFormData = {};
      //default value for form submission
      createLeads.kycFormSubmitted = false;

      //generate Id -- ONLY FOR TEMP USE
      createLeads.randomId = Math.floor(10000 + Math.random() * 90000);

      //list of object (ocr image data and ocr info)
      createLeads.files = [];
       //navigation data   
      createLeads.navigation = [{"name":"UPLOAD","detail":"Id Proof, Adress Proof & Salary Slip","image":"icon_upload.png","activeimage":"icon_upload_active.png","active":true,"completed":false},{"image":"arrow_right.png","active":true},{"name":"RUN","detail":"OCR Process","image":"icon_run.png","activeimage":"icon_run_active.png","active":false,"completed":false},{"image":"arrow_right.png","active":true},{"name":"VERIFY & SUBMIT","detail":"Information","image":"icon_verify.png","activeimage":"icon_verify_active.png","active":false,"completed":false}];
      
      /***Get Customer Id - Store it for future reference**/
      $http.get(ClientAPI.name+'/onboard/create').then(function(response){
          //store customer id
          OCRData.customerId = response.data.customerId;
      });

      /***Browse File - Trigger Method when user click browse button to upload docs**/
      createLeads.browseFiles = function(element){
          //hack to trigger click
          var selectElement = document.querySelector(element);
          selectElement.click();
         
      };

     /***OCR buttons Labels - Allow user to rotate and zoom updated image"**/
      createLeads.myButtonLabels = {
        rotateLeft: '<div class="flex-horizontal"><i class="fa fa-undo" aria-hidden="true"></i><span>Rotate Left</span></div>',
        rotateRight: '<div class="flex-horizontal"><i class="fa fa-repeat" aria-hidden="true"></i><span>Rotate Right</span></div>',
        zoomIn: '<div class="flex-horizontal"><i class="fa fa-search-plus" aria-hidden="true"></i><span>Zoom In</span></div>',
        zoomOut: '<div class="flex-horizontal"><i class="fa fa-search-minus" aria-hidden="true"></i><span>Zoom Out</span></div>',
        fit: '<div class="flex-horizontal"><i class="fa fa-arrows-alt" aria-hidden="true"></i><span>Fit to Screen</span></div>'
      }

      /***Click OCR Tab - Trigger Method when user click OCR Tabs "upload, run and verify"**/
      createLeads.clicktab = function(tabname){
        //if click on upload and run
        if(tabname === "UPLOAD" || tabname === "RUN"){
          //stop if no files uploaded
          if(!createLeads.files.length){return;}
          //update name
          createLeads.activeTab = tabname;
        }else{
          //stop if OCR process not completed
          if(!createLeads.OCRCompleted){return;}
          //update name
          createLeads.activeTab = tabname;
        }
      };

      /***Validation to Verify if user uploaded the correct image***/
      //Note the is temp logic based on existing business requirement
      function incorrectFileUploaded(index){
          //list of files which are to be used for demo
          var files = [
            {passport: 'Passport_1.png', salary:'STL_1.jpg'},
            {passport: 'Passport_2.jpg', salary:'STL_2.jpg'},
            {passport: 'Passport_3.jpg', salary:'STL_3.jpg'},
            {passport: 'Passport_4.jpg', salary:'STL_4.png'},
            {passport: 'Passport_5.jpg', salary:'STL_5.jpg'}
          ];
          //capture file name
          var fileName = createLeads.files[index].filename;
          //initially user need to upload passport
          if(index === 0 && !(_.includes(fileName, 'Passport'))){
              return true;
          //if user selected salary slip
          }else if(index === 1){
              //ensure the doc match with uploaded passport doc
              var selectedDoc = _.find(files, {passport: createLeads.files[0].filename});
              if(fileName !== selectedDoc.salary){
                return true;
              }
          }
          return false;
      }

      /***File Change - Trigger Method when user select file"**/
      createLeads.filechange = function(index, doctype){
        //if validation failed
       if(incorrectFileUploaded(index)){
          //show notification
           Notification.error({message: 'Please select a valid '+doctype.toLowerCase(), positionX: 'center', delay: 4000}); 
           //remove selected doc
           createLeads.files.splice(index, 1);
           return;
        }
        //update name
        createLeads.activeTab = "RUN";
        //Temp hack to auto select the tab
        //Note: need to fix from angular way
        if(index == 1){
          setTimeout(function(){
              //trigger click event manually
              var element = document.querySelector('.nav-tabs li:nth-child(2) > a');
              element.click();
          }, 200);
        }

        //iterate and update the status
        angular.forEach(createLeads.navigation, function(value, key){
            if(value.name === 'UPLOAD'){
              value.completed = true;
            }
            if(value.name === 'RUN'){
              value.active = true;
            }
        });

        //set default feature for each uploaded file data
        setTimeout(function(){
          angular.forEach(createLeads.files, function(value, key){
              value.styles = {transform: 'rotate(0deg)'}
              value.styleHistory = {};
              //value.processCompleted = false;
          });
        }, 200);
      };

      /***Delete Item - Trigger Method when user delete button"**/
      createLeads.deleteItem = function(item){
        //remove item from array
        _.remove(createLeads.files, {
          filename: item
        });

        //update the tab state based on user action
        //if all upload data is deleted
        if(createLeads.files.length === 0){
            //update button state
            createLeads.OCRCompleted = false;
            createLeads.allowSalaryUpload = false;

          //switch user to first page
          createLeads.activeTab = "UPLOAD";
          //update the menu state accordingly
          angular.forEach(createLeads.navigation, function(value, key){
              if(value.name === 'UPLOAD'){
                value.completed = false;
              }
              if(value.name === 'RUN'){
                value.active = false;
              }
          });
        }else{
            //update button state
            createLeads.OCRCompleted = false;
            createLeads.allowSalaryUpload = true;
            //update the menu state accordingly
            angular.forEach(createLeads.navigation, function(value, key){
                if(value.name === 'RUN'){
                  value.completed = false;
                }
                if(value.name === 'VERIFY & SUBMIT'){
                  value.active = false;
                }
            });
        }
      };

 
      /*** Continue Audit - Trigger Method when user click on continue button"**/
      createLeads.continueAuditProcess = function(){
          //prepare payload data object
          var requestData = {
            //form_audit
            document_type:"data_audit",
            audit_data : []
          }

          //iterate and merge the data
          angular.forEach(createLeads.files, function(value, key){
              var mergedData = {};
              _.assign(mergedData, value.ocrReponse, value.ocrRequest);
              requestData.audit_data.push(mergedData);
          });
          
          //prepare request process object
          var processOCRdata = {
           method: 'POST',
           url: ClientAPI.name+'/onboard/',
           data: requestData
          };

          //trigger request
          $http(processOCRdata).then(function(response){
            //update the active state
            createLeads.activeTab = "VERIFY & SUBMIT";
            createLeads.OCRCompleted = true;
            
            //store response data
            createLeads.ocrFormData = response.data;

            //if person name exist, split name and merge with existing object
            if(createLeads.ocrFormData['Persons Name']){
              _.assign(createLeads.ocrFormData, OCRData.splitName(createLeads.ocrFormData["Person's Name"]));
            }
            //Hardcode employer location as per request
            createLeads.ocrFormData.Location = 'UAE';
            //update active state
            angular.forEach(createLeads.navigation, function(value, key){
              if(value.name === 'VERIFY & SUBMIT'){
                value.active = true;
              }

              if(value.name === 'RUN'){
                value.completed = true;
              }
            });

          }, function(error){
              console.log(error);
          });


      };

      /*** Run OCR - Trigger Method when user trigger ocr process**/
      createLeads.runOCR = function(item, processCompletionStatus){
          //stop if already completed
          if(processCompletionStatus){return;}

          //hold current item
          var currentItem = createLeads.files[item],
          //covert to lowercase
          filename = currentItem.filename.toLowerCase();
          //store doctype based on selected doc
          document_type = _.includes(filename, 'passport') ? 'id_proof' : 'salary_proof';
          
          //create request object
          var runOcr = {
           method: 'POST',
           url: ClientAPI.name+'/onboard/',
           data: {
            document_type:document_type,
            base64_string: 'data:image/png;base64,'+ createLeads.files[item].base64,
            customerId: OCRData.customerId
            }
          };

          //trigger request
          $http(runOcr).then(function(response){
              //store response
              var responseData = response.data;
 	     
	      if(responseData.Name != undefined){
		var clientName = responseData.Name.split(' '); 
		if(clientName.length == 3){
			responseData['First Name'] = clientName[0]; 
			responseData['Middle Name'] = clientName[1]; 
			responseData['Last Name'] = clientName[2]; 
		}else if(clientName.length == 2){
			responseData['First Name'] = clientName[0]; 
			responseData['Last Name'] = clientName[1];
		}else if(clientName.length == 1){
			responseData['First Name'] = clientName[0];  
		}
              }
              //store audit doctype based on selected doc
              var auditDocType = (document_type === 'id_proof') ? 'id_audit' : 'salary_audit';

              //update the process status
              createLeads.files[item].processCompleted = true;

              //store response data and keys
              createLeads.files[item].ocrReponse = responseData;
              createLeads.files[item].ocrKeys = responseData.keywordOrder;

              //based on document type allow user permission to take next action
              if(document_type === 'id_proof'){
                  createLeads.allowSalaryUpload = true;
              }else{
                  createLeads.OCRCompleted = true;
                  createLeads.allowSalaryUpload = false;
              }

              //store customer id and doctype for future reference
              createLeads.files[item].ocrRequest = {
                customerId: OCRData.customerId,
                document_type: auditDocType
              };

          }, function(error){
              console.log(error);
          });
      };

     /*** Sumit Form - Trigger Method when user submit button "**/
      createLeads.formSubmit = function(){

          //doing some monontonous work :(
          //merge props into one
          var formData = createLeads.ocrFormData;
          createLeads.ocrFormData['Persons Name'] = (formData["First Name"] || '') + " " + (formData["Middle Name"] || '') + " " + (formData["Last Name"] ||'');
          

          createLeads.ocrFormData.document_type = "form_audit";

        
          //prepare request process object
          var ocrFormSubmit = {
           method: 'POST',
           url: ClientAPI.name+'/onboard/',
           data: createLeads.ocrFormData
          };

          //trigger request
          $http(ocrFormSubmit).then(function(response){
            //store response data
            createLeads.ocrSubmittedResponse = response.data;
            //show submission message
            createLeads.kycFormSubmitted = true;

            //update active state
            angular.forEach(createLeads.navigation, function(value, key){
              if(value.name === 'VERIFY & SUBMIT'){
                value.completed = true;
              }
            });
       
          }, function(error){
              console.log(error);
          });


      };

      /*** reload state - start fresh "**/
      createLeads.reload = function(){
        $state.go($state.current, {}, {reload: true});
      };

    })
    .filter('sliceext', function() {
      return function(input) {
      var output;
      output = input.slice(0, -4);
      return output;
    }

  })
  .factory('OCRData', function(){

      var id_proof = ["Passport Number", "Date of Issue", "DocumentType",
      "Issueing Country/Organisation", "Date of Expiry", "Nationality"];

      var salary_proof = ["Salary Transfer Clause", "Notification Clause",
      "Address To HSBC", "Clearance Letter Clause", "End of Benefits Clause"];

      var consolidatedProps = {
        "Personal Information": {"First Name":"", "Middle Name":"", "Last Name":"", "Father Name":"", "Mother Name":"", "Date of Birth":""},
        "Passport Details": {"Passport Number":"", "Date of Issue":"", "Place of Issue":"", "Date of Expiry":"", "Old Passport Number":""},
        "Employer's Details": {"Employer Name":"", "Location":"", "Employee Code":"", "Payslip for the of Month of":"", "Total Earnings in Month":""},
        "Communication": {"Address":"", "State":"", "Country":"", "Phone Number":""}
      };

      function splitName(name){
        var personname = name.split(' ');
        return {
          "First Name": personname[0] || '',
          "Middle Name": personname[2] || '',
          "Last Name": personname[1] || ''
        }
      }

      return {
          id_proof:id_proof,
          salary_proof:salary_proof,
          customerId: null,
          //http://34.249.35.24:8000, http://192.168.247.171:8000, http://34.248.34.18, http://192.168.247.241:8000
          server: 'http://172.22.52.23:8000',
          consolidatedProps: consolidatedProps,
          splitName: splitName

      };

  });


})();
