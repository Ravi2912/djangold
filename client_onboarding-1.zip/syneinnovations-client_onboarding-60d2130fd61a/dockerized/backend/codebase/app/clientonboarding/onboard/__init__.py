import pymongo;

from pymongo import MongoClient;
# client = MongoClient();
# db = client.test_database;
# collection = db.test_collection;
# posts = db.posts;
# post = {"author": "Mike","text": "My first blog post!","tags": ["mongodb", "python", "pymongo"]};
# post_id = posts.insert_one(post).inserted_id;
# print(post_id);
# newPosts = posts.find_one({"author": "Mike"});
# print(newPosts);