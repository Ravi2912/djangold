from onboard.mongo import MongoConnector


# This file contains all the operations which are related to admins portal.

class AdminService:
    # Fetch all the fresh leads which have neither been rejected nor approved.
    def get_leads(self, db_name, collection_name):
        admin_service = AdminService()
        query = {"status": None}
        leads = admin_service.get_records(db_name, collection_name, query)
        for lead in leads:
            if 'base64' in lead:
                del lead['base64']
        return leads

    # Fetch records of all the customers
    def get_history(self, db_name, collection_name):
        admin_service = AdminService()
        query = {}
        histories = admin_service.get_records(db_name, collection_name, query)
        for history in histories:
            if 'base64' in history:
                del history['base64']
        return histories

    # Fetch customers with rejected records
    def get_deferred(self, db_name, collection_name):
        admin_service = AdminService()
        query = {"status": "0"}
        deferreds = admin_service.get_records(db_name, collection_name, query)
        for deferred in deferreds:
            if 'base64' in deferred:
                del deferred['base64']
        return deferreds

    def get_image(self, db_name, customer_id, document_type):
        admin_service = AdminService()
        customer_id = int(customer_id)
        query = {"customerId": customer_id}
        collection_name = 'Identity'
        if document_type == 'salary_proof':
            collection_name = 'Salary'
        records = admin_service.get_records(db_name, collection_name, query)
        image = {}
        if records.__len__() > 0:
            if 'base64' in records[0]:
                image['image'] = records[0]['base64']
            if 'idImageWidth' in records[0]:
                image['width'] = records[0]['InputImageWidth']
            if 'InputImageHeight' in records[0]:
                image['height'] = records[0]['InputImageHeight']
        return image

    def get_id_image(self, db_name, customer_id):
        admin_service = AdminService()
        customer_id = int(customer_id)
        query = {"customerId": customer_id}
        collection_name = 'Identity'
        records = admin_service.get_records(db_name, collection_name, query)
        image = {}
        if records.__len__() > 0:
            if 'idImage' in records[0]:
                image['idImage'] = records[0]['idImage']
            if 'idImageHeight' in records[0]:
                image['height'] = records[0]['idImageHeight']
            if 'idImageWidth' in records[0]:
                image['width'] = records[0]['idImageWidth']
            image['customerId'] = customer_id
        return image

    def approve_request(self, db_name, collection_name, customer_id):
        customer_id = int(customer_id)
        admin_service = AdminService()
        query = {"customerId": customer_id}
        update = {"$set": {"status": "1"}}
        return admin_service.update_record(db_name, collection_name, query, update)

    def reject_request(self, db_name, collection_name, customer_id):
        customer_id = int(customer_id)
        admin_service = AdminService()
        query = {"customerId": customer_id}
        update = {"$set": {"status": "0"}}
        return admin_service.update_record(db_name, collection_name, query, update)

    def get_records(self, db_name, collection_name, query, sort_column='updatedOn'):
        connection = MongoConnector.get_connection(db_name, collection_name)
        cursor = connection.find(query).sort(sort_column, -1)
        records = []
        if cursor.count() > 0:
            for record in cursor:
                del record['_id']
                records.append(record)
        return records

    def update_record(self, db_name, collection_name, query, update):
        connection = MongoConnector.get_connection(db_name, collection_name)
        connection.update_one(query, update)
        response = {}
        response['status'] = 'success'
        return response

    def get_customer_details(self, db_name, collection_name, collection_name_identity_audit,
                             collection_name_salary_audit, customer_id):
        customer_id = int(customer_id)
        query = {"customerId": customer_id}
        admin_service = AdminService()
        customer_image = admin_service.get_id_image(db_name, customer_id)
        customer_form_data = admin_service.get_records(db_name, collection_name, query)[0]
        if 'idImage' in customer_image:
            customer_form_data['idImage'] = customer_image['idImage']
        customer_id_data = admin_service.get_records(db_name, collection_name_identity_audit, query)[0]
        customer_salary_data = admin_service.get_records(db_name, collection_name_salary_audit, query)[0]
        mismatch = []
        for key, value in customer_form_data.items():
            if key in customer_id_data:
                if customer_form_data[key] != customer_id_data[key]:
                    mismatch.append(key)
            elif key in customer_salary_data:
                if customer_form_data[key] != customer_salary_data[key]:
                    mismatch.append(key)
        customer_form_data['mismatch'] = mismatch
        return customer_form_data
