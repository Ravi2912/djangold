import numpy as np
import cv2
import sys
import os

faceCascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

img = cv2.imread(sys.argv[1])
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

faces = faceCascade.detectMultiScale(
    gray,
    scaleFactor=1.1,
    minNeighbors=5,
    minSize=(30, 30),
    flags = cv2.cv.CV_HAAR_SCALE_IMAGE
)
for (x, y, w, h) in faces:
    cv2.rectangle(img, (x-25, y-40), (x+w+30, y+h+50), (0, 255, 0), 2)
cropped_imge = img[(y-40):(y+h+50), (x-25):(x+w+30)]
# img = cv2.resize(img,(700,700))
cropped_imge = img[(y-40):(y+h+50), (x-25):(x+w+30)]
cv2.imshow("Faces found" ,cropped_imge)
cv2.waitKey(0)