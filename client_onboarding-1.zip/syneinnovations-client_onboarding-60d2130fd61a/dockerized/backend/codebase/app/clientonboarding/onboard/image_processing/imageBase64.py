from PIL import Image
from io import BytesIO
import base64
import cv2
import numpy

class base64Image():

    def __init__(self, b64_Filedata = None):
        self.b64_Filedata = b64_Filedata
        self.pil_Image = None
        self.cv_Image = None

    def convert2PIL_Image(self, b64_Filedata = None):

        if b64_Filedata is not None:

            self.b64_Filedata = b64_Filedata

        if self.b64_Filedata is not None:

            self.pil_Image = Image.open(BytesIO(base64.b64decode(self.b64_Filedata)))

        else:

            self.pil_Image = None


    def convert2CV_Image(self, b64_Filedata = None):

        if b64_Filedata is not None:

            self.b64_Filedata = b64_Filedata

        self.convert2PIL_Image()

        if self.pil_Image is not None:

            self.cv_Image = numpy.array(self.pil_Image)

    def convertCV_Image2Base64(self, cv_Image = None):

        if cv_Image is not None:

            cnt = cv2.imencode('.png',cv_Image)[1]

            b64 = base64.encodestring(cnt)
            return b64

        else:
            
            return ""


