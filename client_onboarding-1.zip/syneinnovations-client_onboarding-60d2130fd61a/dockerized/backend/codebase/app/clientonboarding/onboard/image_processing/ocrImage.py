import pytesseract
from PIL import Image
import cv2


class DocOcr():
    def __init__(self):
        self.image = None
        self.gray_image = None
        self.OCR_result = ""
        self.grayOCR_result = ""

    def load(self, image, gray_image=None):

        self.image = image
        if gray_image is not None:
            self.gray_image = gray_image
        else:
            self.gray_image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)

    #
    # def set_resizingFactor(self, fx, fy):
    #     self.resizingFactor = [fx, fy]

    def runGrayImageOCR(self):

        # re_gray_image = cv2.resize(self.gray_image, (0,0), fx=self.resizingFactor[0], fy=self.resizingFactor[1])
        pil_gray_img = Image.fromarray(self.gray_image)
        print 'Till Here'
        self.grayOCR_result = pytesseract.image_to_string(pil_gray_img)

    def runImageOCR(self):

        # re_image = cv2.resize(self.gray_image, (0,0), fx=self.resizingFactor[0], fy=self.resizingFactor[1])

        pil_img = Image.fromarray(self.image)

        self.OCR_result = pytesseract.image_to_string(pil_img)