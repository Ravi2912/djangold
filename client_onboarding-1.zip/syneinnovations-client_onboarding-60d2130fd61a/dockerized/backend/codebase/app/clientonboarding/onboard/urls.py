from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^approve', views.approve, name='approve'),
    url(r'^create', views.create_customer, name='create_customer'),
    url(r'^reject', views.reject, name='reject'),
    url(r'^leads', views.fetch_leads, name='fetch_leads'),
    url(r'^deferred', views.fetch_deferred, name='fetch_deferred'),
    url(r'^history', views.fetch_history, name='fetch_history'),
    url(r'^details', views.fetch_customer_details, name='fetch_customer_details'),
    url(r'^image', views.fetch_image, name='fetch_image'),
    url(r'^idImage', views.fetch_image, name='fetch_id_image'),
]