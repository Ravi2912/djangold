import json
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from onboard.onboard_service import OnboardService
from onboard.admin_service import AdminService
from datetime import datetime

# Get Input json
# Parse and get details
# Create an object and call OCR code
# Get the response, parse in an object , store in Mongo
# Send the response (in JSON format) back to UI

admin_service = AdminService()

@csrf_exempt
def create_customer(request):
    if request.method == 'GET':
        cob = COB()
        response = OnboardService().create_customer(cob.db_name)
        return HttpResponse(COB().convert_to_json(response))

@csrf_exempt
def index(request):
    if request.method == 'POST':
        cob = COB()
        request_json = cob.map_json(request.body)
        response = cob.process_image(request_json)
        return HttpResponse(response)


@csrf_exempt
def approve(request):
    if request.method == 'POST':
        cob = COB()
        request_json = cob.map_json(request.body)
        response = admin_service.approve_request(cob.db_name, cob.collection_name_form_audit,
                                                 request_json['customerId'])
        return HttpResponse(cob.convert_to_json(response))


@csrf_exempt
def reject(request):
    if request.method == 'POST':
        cob = COB()
        request_json = cob.map_json(request.body)
        response = admin_service.reject_request(cob.db_name, cob.collection_name_form_audit,
                                                request_json['customerId'])
        return HttpResponse(cob.convert_to_json(response))


# Fetch all the customer's data that are neither approved nor rejected
@csrf_exempt
def fetch_leads(request):
    if request.method == 'GET':
        cob = COB()
        response = admin_service.get_leads(cob.db_name, cob.collection_name_form_audit)
        if response is not None and len(response) > 0:
            response = cob.convert_to_json(response)
        else:
            response = '[]'
        return HttpResponse(response)


# Fetch all the details of a customer by customerId.
# Provide all the incorrect fields in an array.
@csrf_exempt
def fetch_customer_details(request):
    if request.method == 'POST':
        cob = COB()
        request_json = cob.map_json(request.body)
        response = cob.convert_to_json(admin_service.get_customer_details(cob.db_name, cob.collection_name_form_audit,
                                                                          cob.collection_name_identity_audit,
                                                                          cob.collection_name_salary_audit,
                                                                          request_json['customerId']))
        return HttpResponse(response)


# Fetch the image provided for sample document
@csrf_exempt
def fetch_image(request):
    if request.method == 'POST':
        cob = COB()
        request_json = cob.map_json(request.body)
        response = cob.convert_to_json(
            admin_service.get_image(cob.db_name, request_json['customerId'], request_json['document_type']))
        return HttpResponse(response)


# Fetch the image provided for sample document
@csrf_exempt
def fetch_id_image(request):
    if request.method == 'POST':
        cob = COB()
        request_json = cob.map_json(request.body)
        response = cob.convert_to_json(
            admin_service.get_id_image(cob.db_name, request_json['customerId'], request_json['document_type']))
        return HttpResponse(response)


@csrf_exempt
def fetch_deferred(request):
    if request.method == 'GET':
        cob = COB()
        response = admin_service.get_deferred(cob.db_name, cob.collection_name_form_audit)
        print response
        if response is not None and len(response) > 0:
            response = cob.convert_to_json(response)
        else:
            response = '[]'
        return HttpResponse(response)


# Fetch all the customers data that have been approved
@csrf_exempt
def fetch_history(request):
    if request.method == 'GET':
        cob = COB()
        response = admin_service.get_history(cob.db_name, cob.collection_name_form_audit)
        if response is not None and len(response) > 0:
            response = cob.convert_to_json(response)
        else:
            response = '[]'
        return HttpResponse(response)


class COB:
    db_name = 'ClientOnboarding'
    collection_name_identity = 'Identity'
    collection_name_identity_audit = 'IdentityAudit'
    collection_name_salary = 'Salary'
    collection_name_salary_audit = 'SalaryAudit'
    collection_name_form_audit = 'FormAudit'

    document_type_identity = 'id_proof'
    document_type_identity_audit = 'id_audit'
    document_type_salary = 'salary_proof'
    document_type_salary_audit = 'salary_audit'
    document_type_form_audit = 'form_audit'

    # Gets the request object
    def process_image(self, request_json):
        cob = COB()
        # Call OCR code and Get Dictionary
        service = OnboardService()
        data = {}
        if request_json['document_type'] in ('id_proof', 'salary_proof'):
            base64 = request_json['base64_string']
            base64 = base64[base64.index(',') + 1:]
            data = service.perform_ocr(base64, request_json['document_type'])
            data['base64'] = request_json['base64_string']
            #            data['image_type'] = request_json['image_type']
            if 'customerId' in request_json:
                data['customerId'] = int(request_json['customerId'])
            # Save data to Mongo
            response = cob.save_data(request_json, data, service)

        elif request_json['document_type'] == 'form_audit':
            data = request_json
            data['customerId'] = int(request_json['customerId'])
            cob.save_data(request_json, data, service)
            response = cob.convert_to_json(
                admin_service.get_id_image(cob.db_name, request_json['customerId']))

        else:
            response = cob.save_audit_data(request_json, data, service)

        return response

    def map_json(self, data):
        return json.loads(data.decode('utf-8'))

    def save_data(self, request_json, data, service):
        cob = COB()
        collection_name = cob.get_collection(request_json['document_type'])
        data['insertedOn'] = datetime.now().isoformat()
        data['updatedOn'] = datetime.now().isoformat()
        nlp_output = service.store_data(cob.db_name, collection_name, data)
        response = cob.convert_to_json(nlp_output)
        return response

    def save_audit_data(self, request_json, data, service):
        cob = COB()
        audit_data = request_json['audit_data'];
        if audit_data is not None:
            for audit in audit_data:
                collection_name = cob.get_collection(audit['document_type'])
                audit['insertedOn'] = datetime.now().isoformat()
                audit['updatedOn'] = datetime.now().isoformat()
                service.store_data(cob.db_name, collection_name, audit)
                response = cob.convert_to_json(
                    service.retrieve_form_data(audit['customerId'], cob.db_name, cob.collection_name_salary_audit,
                                               cob.collection_name_identity_audit))
            return response

    # Converts the provided object into its json equivalent and returns the same.
    def convert_to_json(self, obj):
        if obj != None:
            if 'insertedOn' in obj:
                del obj['insertedOn']
            if 'updatedOn' in obj:
                del obj['updatedOn']
            if 'base64' in obj:
                del obj['base64']
            if '_id' in obj:
                del obj['_id']
            return json.dumps(obj)
        return '{}'

    def get_collection(self, document_type):
        cob = COB()
        if document_type == cob.document_type_identity:
            return cob.collection_name_identity
        if document_type == cob.document_type_identity_audit:
            return cob.collection_name_identity_audit
        if document_type == cob.document_type_salary:
            return cob.collection_name_salary
        if document_type == cob.document_type_salary_audit:
            return cob.collection_name_salary_audit
        if document_type == cob.document_type_form_audit:
            return cob.collection_name_form_audit
