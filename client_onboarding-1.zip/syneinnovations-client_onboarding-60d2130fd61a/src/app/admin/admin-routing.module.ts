import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin.component';
import { PageDashboardComponent } from './page-dashboard/page-dashboard.component';
import { DashboardListComponent } from './page-dashboard/dashboard-list/dashboard-list.component';

const routes: Routes = [
	// {
	// 	path: 'dashboard',
	// 	component: AdminComponent,
	// 	redirectTo: '/admin/dashboard/leads',
	// 	children: [
	// 		{ path: '', component: PageDashboardComponent }
	// 	],
	// 	data: { state: 'dashboard' }
	// },
	// {
	// 	path: 'dashboard',
	// 	component: AdminComponent,
	// 	redirectTo: '/admin/dashboard/deferred',
	// 	children: [
	// 		{ path: '', component: PageDashboardComponent }
	// 	],
	// 	data: { state: 'deferred' }
	// },
	// {
	// 	path: 'dashboard',
	// 	component: AdminComponent,
	// 	redirectTo: '/admin/dashboard/history',
	// 	children: [
	// 		{ path: '', component: PageDashboardComponent }
	// 	],
	// 	data: { state: 'history' }
	// },
	{
		path: 'dashboard/:pageId',
		component: AdminComponent,
		children: [
			{ path: '', component: PageDashboardComponent }
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class AdminRoutingModule { }
