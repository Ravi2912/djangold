export interface Company {
  companyName: string,
  img: string
}