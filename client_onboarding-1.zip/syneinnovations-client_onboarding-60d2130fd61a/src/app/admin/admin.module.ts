import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { MaterialModule } from '../shared/material.module';
import { SharedModule } from '../shared/shared.module';
import { PipesModule } from '../pipes/pipes.module';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { PageDashboardComponent } from './page-dashboard/page-dashboard.component';
import { AdminHeaderComponent } from './admin-header/admin-header.component';
import { LeftNavComponent } from './left-nav/left-nav.component';
import { DashboardDetailsComponent } from './page-dashboard/dashboard-details/dashboard-details.component';
import { DashboardListComponent } from './page-dashboard/dashboard-list/dashboard-list.component';
import { ModalComponent } from './page-dashboard/modal/modal.component';

@NgModule({
    imports: [
        CommonModule,
        AdminRoutingModule,
        SharedModule,
        PipesModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule
    ],
    declarations: [AdminComponent, PageDashboardComponent, AdminHeaderComponent, LeftNavComponent, DashboardDetailsComponent, DashboardListComponent, ModalComponent]
})
export class AdminModule { }
