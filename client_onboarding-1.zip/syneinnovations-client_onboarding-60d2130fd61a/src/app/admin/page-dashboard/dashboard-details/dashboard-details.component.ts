import { Component, OnInit, Input, Output,  EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Client } from 'src/app/client/client.interfaces';
import { ngDevModeResetPerfCounters } from '@angular/core/src/render3/ng_dev_mode';

declare var UIkit: any;

@Component({
  selector: 'app-dashboard-details',
  templateUrl: './dashboard-details.component.html',
  styleUrls: ['./dashboard-details.component.scss']
})
export class DashboardDetailsComponent implements OnInit {

  @Input() client: Client;
  @Output() onClick = new EventEmitter<string>();
  @Input() pageId;
  @Input() counter;
  @Input() clientLoaded;

  modalType: string = '';
  clientImage: any = 'https://via.placeholder.com/726x480';

  constructor(private http: HttpClient) { 
  }

  ngOnInit() {
  }

  onClickHandler(action: string){

    this.onClick.emit(action); 
  }

  getDetailImage(customerId, document_type) {
    let modalBox = document.getElementById('modal-example');
    this.clientImage = '';
    UIkit.modal(modalBox).show();
 
    // Needs a spinner while we load the image
 
    this.http.post('https://finlabs-neo.synechron.net/admins/image', { customerId: customerId, document_type: document_type })
      .subscribe(
        data => {
          this.clientImage = data;
 
        },
        error => {
          console.log("Request error ocucred ", error);
        }
      );
  };
}
