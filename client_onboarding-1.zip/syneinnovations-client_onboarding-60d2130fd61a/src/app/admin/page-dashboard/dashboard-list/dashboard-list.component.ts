import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dashboard-list',
  templateUrl: './dashboard-list.component.html',
  styleUrls: ['./dashboard-list.component.scss']
})
export class DashboardListComponent implements OnInit {

  @Input() listItems;
  @Output() onClick = new EventEmitter<number>();

  clientsByName = [];
  filterList : any;
  client = {};
  itemSelected: number;
  clientChanged = true;

  constructor() {
    this.filterList = this.listItems;
  }

  ngOnInit() {
    this.filterList = this.listItems;
  }
  
  ngOnChanges() {
    this.filterList = this.listItems;    
  }

  onClickHandler(n: number){
    this.itemSelected = n;
    this.onClick.emit(n); 
  }

  onInputHandler(event) {
    let keyWord = event.target.value.toLowerCase();
    this.filterList = this.listItems.filter((c) => {
      if(c['Name'] && c['Name'].toLowerCase().indexOf(keyWord) !=-1){
          return c;
      }
    });
  }
}