import { Component, OnInit, Input } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit {

  @Input() docImage;
  // @Input() docType;

  constructor(public _DomSanitizer: DomSanitizer) { }

  ngOnInit() {
    
  }

}
