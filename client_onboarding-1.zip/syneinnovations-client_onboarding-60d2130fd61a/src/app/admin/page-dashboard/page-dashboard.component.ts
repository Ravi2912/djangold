import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute, ActivationStart, NavigationEnd } from '@angular/router';

import { ClientService } from '../../client/client.service';

@Component({
  selector: 'app-page-dashboard',
  templateUrl: './page-dashboard.component.html',
  styleUrls: ['./page-dashboard.component.scss']
})
export class PageDashboardComponent implements OnInit {

  listItems: any = [];
  client = {};
  clientsByName = [];
  pageId: string;

  isLoading = true;
  counter = 0;
  clientLoaded = false;

  constructor(private clientService: ClientService, private http: HttpClient, private router: Router, private route: ActivatedRoute) {
    this.client = clientService.getClient();


    this.pageId = this.route.snapshot.params.pageId;


  }
  ngOnInit() {
    this.getLeads(this.route.snapshot.params.pageId);
    
    this.router.events.subscribe((ev) => {
      if (ev instanceof NavigationEnd) {
        this.getLeads(this.route.snapshot.params.pageId);

      }
    });
  }


  getLeads(id) {
    this.isLoading = true;
    this.http.get(`https://finlabs-neo.synechron.net/admins/${id}`)
      .subscribe(
        data => {
          this.listItems = data;
          this.isLoading = false;
         
        },
        error => {
          console.log("Request error ocucred ", error);
        }
      );
  };

  getItemData(customerId) {
    this.client['idImage'] = "";
    this.counter++;
    this.http.post('https://finlabs-neo.synechron.net/admins/details', { customerId: customerId })
      .subscribe(
        data => {
          this.client = data;
          this.clientLoaded = true;
          this.counter++;
          // how to do it in nicer way?
          for (let c of this.listItems) {
            if (this.client['customerId'] = c.customerId) {
              this.client['updatedOn'] = c.updatedOn;
              this.client['insertedOn'] = c.insertedOn;
            }
          }

          this.clientService.setClient(this.client);
          
        },
        error => {
          console.log("Request error ocucred ", error);
        }
      );
  };

  processRequest(action) {

    this.http.post('https://finlabs-neo.synechron.net/admins/' + action, { customerId: this.client['customerId'] })
      .subscribe(
        data => {
          this.getLeads(this.route.snapshot.params.pageId);
          //      Notification.success({message: 'Request is successfully submitted.', positionX: 'center', delay: 4000});
          this.client = {};
          
        },
        error => {
          console.log("Request error ocucred ", error);
        }
      );
  }
}
