import { sequence, trigger, stagger, animate, style, group, query, transition, keyframes, animateChild } from '@angular/animations';
// export const query = function(s,a,o={optional:true}){
//   return q(s,a,o);
// };

export const blockStagger = trigger('blockStagger', [
  transition(':enter', [
    query('.stagger', style({ opacity: 0 }), { optional: true }),
    query('.stagger', stagger(100, [
      style({ transform: 'scale(1.1)' }),
      animate('1s cubic-bezier(.75,-0.48,.26,1.52)', style({ transform: 'scale(1)', opacity: 1 })),
    ]), { optional: true }),
  ]),
  transition(':leave', [
    query('.stagger', stagger(100, [
      style({ transform: 'scale(1)', opacity: 1 }),
      animate('500ms cubic-bezier(.75,-0.48,.26,1.52)', style({ transform: 'scale(1.1)', opacity: 0 })),
    ]), { optional: true }),
  ])
]);


export const staggerIn = trigger('staggerIn', [
  transition(':enter', [
    query('.stagger-in', style({ opacity: 0 }), { optional: true }),
    query('.stagger-in', stagger(100, [
      style({ transform: 'scale(1.1)' }),
      animate('1s cubic-bezier(.75,-0.48,.26,.52)', style({ transform: 'scale(1)', opacity: 1 })),
    ]), { optional: true }),
  ])
]);


export const containerFade = trigger('containerFade', [
  transition(':enter', [
    query('.container-fade', [
      style({ opacity: 0 }),
      animate('800ms ease', style({ opacity: 1 })),
    ], { optional: true }),
  ]),
  transition(':leave', [
    query('.container-fade', [
      style({ opacity: 1 }),
      animate('800ms ease', style({ opacity: 0 })),
    ], { optional: true }),
  ])
]);

export const routerTransition = trigger('routerTransition', [
  transition('* => *', [
    sequence([
      query(':leave', animateChild(), { optional: true }),
      query(':enter', animateChild(), { optional: true }),
    ])
  ])
]);

