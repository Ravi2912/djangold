import { Component } from '@angular/core';
import { AuthGuardService } from './core/services/auth-guard.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'SynAI';

  constructor(private authGuardService: AuthGuardService) { }

  getDepth(outlet) {
    return outlet.activatedRouteData['depth'];
  }


}
