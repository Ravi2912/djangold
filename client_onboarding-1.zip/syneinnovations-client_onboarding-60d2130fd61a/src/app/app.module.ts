import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';


import { CoreModule } from './core/core.module';
import { AppComponent } from './app.component';

// Angular 4
//import { Base64 } from 'angular-base64-upload';

@NgModule({
  declarations: [
    AppComponent
   ],
  imports: [
    BrowserModule,
    CoreModule,
    BrowserAnimationsModule,
    HttpClientModule,
  ],

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 

}
