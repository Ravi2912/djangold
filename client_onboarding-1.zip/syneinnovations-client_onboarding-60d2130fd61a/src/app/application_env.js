  angular
    .module('ClientOnboarding')
    .factory('ClientAPI', function(){
    	  //set the api name and status
    	  //status indicate whether they are active or inactive
    	  //change the setting accordingly. 
    	  var apiUrl;
    	  var environments = [
    	  		//set the prod evn and url - http://34.249.35.24 
    	  		{	
    	  			name: "neo",
	    			url:'https://finlabs-neo.synechron.net',
	    			state: false
	    		},
	    		//set the staging evn and url - http://34.248.34.18
	    		{	
	    			name: "aiml",
	    			url:'https://finlabs-aiml.synechron.net',
	    			state: false
	    		},
	    		//set the staging evn and url
	    		{	
	    			name: "local1",
	    			url:'http://172.22.52.23:8000',
	    			state: false
	    		},
	    		//set the staging evn and url
	    		{	
	    			name: "local2",
	    			url:'http://172.22.52.28:8000',
	    			state: false
					},
					{
						name: "dev",
						url: 'http://localhost:5000',
						state: true
					}
	        ];

	      //set URL based on provided info
	      (function getUrl(){
	      	apiUrl  = _.find(environments, {state: true});;
	      })();


	    //expose to outside world
    	return{
			name : apiUrl.url	    		
    	}
    });
