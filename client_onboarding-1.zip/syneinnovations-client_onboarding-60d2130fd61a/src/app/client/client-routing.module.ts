import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageRunOcrPassportComponent } from './page-run-ocr-passport/page-run-ocr-passport.component';
import { PageVerifyComponent } from './page-verify/page-verify.component';
import { PageSubmitComponent } from './page-submit/page-submit.component';
import { PageRunOcrSlipComponent } from './page-run-ocr-slip/page-run-ocr-slip.component';

const routes: Routes = [
	// {
	// 	path: '',
	// 	redirectTo: 'PageHomeComponent',
	// 	pathMatch: 'full',
	// 	data: { state: 'dashboard'}
  // },
  {
		path: 'ocr-passport',
		component: PageRunOcrPassportComponent,
		children: [
			{ path: '', component: PageRunOcrPassportComponent }
		],
		data: { state: 'ocr-passport', step: 0}
	},
	{
		path: 'ocr-slip',
		component: PageRunOcrSlipComponent,
		children: [
			{ path: '', component: PageRunOcrSlipComponent }
		],
		data: { state: 'ocr-slip', step: 1}
	},
	{
		path: 'verify',
		component: PageVerifyComponent,
		children: [
			{ path: '', component: PageVerifyComponent }
		],
		data: { state: 'verify', step: 2}
	},
	{
		path: 'submit',
		component: PageSubmitComponent,
		children: [
			{ path: '', component: PageSubmitComponent }
		],
		data: { state: 'submit', step: 3}
	},
	// {
	// 	path: '',
	// 	component: AdminComponent,
	// 	children: [
	// 		{ path: '', component: PageDashboardComponent }
	// 	],
	// 	data: { state: 'dashboard'}
	// },
	// {
	// 	path: 'dashboard/:id',
	// 	component: AdminComponent,
	// 	children: [
	// 		{ path: '', component: PageDashboardComponent }
	// 	],
	// 	data: { state: 'dashboard'}
	// }
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class ClientRoutingModule { }
