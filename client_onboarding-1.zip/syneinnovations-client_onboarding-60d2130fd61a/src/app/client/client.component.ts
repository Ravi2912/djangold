import { Component, OnInit } from '@angular/core';
import {routerTransition} from '../app.animations';


@Component({
    selector: 'app-client',
    templateUrl: './client.component.html',
    styleUrls: ['./client.component.scss'],
    animations: [routerTransition],
})
export class ClientComponent implements OnInit {

    constructor() {
        
    }

    ngOnInit() {
        
      
    }

    getState(outlet) {
        
        return outlet.activatedRouteData.state;
      }
}
