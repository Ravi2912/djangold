export interface Client {
  "customerId": number,
  // passport OCR info
  "DOB CD Verification": string,
  "Person's Name": string,
  "Persons Name": string,
  "Date of Birth": string,
  "Date of Expiry": string,
  "Issuing Country/Organisation": string,
  "Passport Number": string,
  "Passport No CD Verification": string,
  "Name": string,
  "Nationality": string,
  "Sex": string,
  
  // from slip
  "Salary": string,
  "Company Name": string,
  "Given Address": string,
  "City": string,
  "State": string,
  "Country": string,
  "Designation": string,
 
  /// new ones form post
  "Address To HSBC": string,
  "Clearance Letter Clause": string,
  "Date of Expiry CD Verification": string,
  "End of Benefits Clause": string,
  "First Name": string,
  "InputImageHeight": number,
  "InputImageWidth": number,
  "Last Name": string,
  "Middle Name": string,
  "Notification Clause": string,
  "Salary Transfer Clause": string,
  "Location": string,
  "updatedOn": string,
  "insertedOn": string,
  "dateOfIssue": string,
  "oldPassportNumber": string,
  
  // delete?
  "document_type": string,
  // location: string,
  // fathersName: string,
  // mothersName: string,
  // profileImage: string,
   "phoneNumber": string,
  "idImage": string,
  "idImageHeight": number,
  "idImageType": string,
  "idImageWidth": number
}