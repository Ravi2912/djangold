import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MaterialModule } from '../shared/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { ClientRoutingModule } from './client-routing.module'
import { PageRunOcrPassportComponent } from './page-run-ocr-passport/page-run-ocr-passport.component';
import { ClientComponent } from './client.component';
import { PageVerifyComponent } from './page-verify/page-verify.component';
import { StepsBarComponent } from '../client/steps-bar/steps-bar.component';
import { PageSubmitComponent } from './page-submit/page-submit.component';
import { PageRunOcrSlipComponent } from './page-run-ocr-slip/page-run-ocr-slip.component';
import { ClientHeaderComponent } from './client-header/client-header.component';

@NgModule({
  imports: [
    CommonModule,
    ClientRoutingModule,
    SharedModule,
    FormsModule,
    // what are those for??
    ReactiveFormsModule,
    MaterialModule
  ],
  // ovde se dodaju komponente
  declarations: [StepsBarComponent, ClientComponent, PageRunOcrPassportComponent, PageVerifyComponent, PageSubmitComponent, PageRunOcrSlipComponent, ClientHeaderComponent]
})
export class ClientModule { }
