import { Injectable } from '@angular/core';

import { Client } from './client.interfaces';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  applicationData: Client;
  steps: any = [
    {
      label: 'Step1: Passport',
      desc: 'Upload & Run OCR',
      img: '../../../assets/passport-icon.svg',
      completed: false,
      active: false,
    },
    {
      label: 'Step 2: Salary Slip',
      desc: 'Upload & Run OCR',
      img: '../../../assets/slip-icon.svg',
      completed: false,
      active: false,
    },
    {
      label: 'Step 3: Verify',
      desc: 'Verify & Edit Information',
      img: '../../../assets/verify-icon.svg',
      completed: false,
      active: false,
    },
    {
      label: 'Step 4: Submit',
      desc: 'Information Submitted',
      img: '../../../assets/submit-icon.svg',
      completed: false,
      active: false,
    }
  ];

  constructor() {
    this.applicationData = {
      "customerId": 0,
      // passport OCR info
      "DOB CD Verification": '',
      "Person's Name": '',
      "Persons Name": '',
      "Date of Birth": '',
      "Date of Expiry": '',
      "Issuing Country/Organisation": '',
      "Passport Number": '',
      "Passport No CD Verification": '',
      "Name": '',
      "Nationality": '',
      "Sex": '',
      // imam sve

      // from slip
      "Salary": '',
      "Company Name": '',
      "Given Address": '',
      "City": '',
      "State": '',
      "Country": '',
      "Designation": '',
      //imam sve

      /// new ones form post
      "Address To HSBC": '',
      "Clearance Letter Clause": '',
      "Date of Expiry CD Verification": '',
      "End of Benefits Clause": '',
      "First Name": '',
      "InputImageHeight": 0,
      "InputImageWidth": 0,
      "Last Name": '',
      "Middle Name": '',
      "Notification Clause": '',
      "Salary Transfer Clause": '',

      // delete?
      "dateOfIssue": '',
      "document_type": '',
      // location: '',
      // fathersName: '',
      // mothersName: '',
      // profileImage: '',
      "oldPassportNumber": '',
      "phoneNumber": '',
      "idImage": '',
      "idImageHeight": 0,
      "idImageType": '',
      "idImageWidth": 0,
      "Location": '',
      "updatedOn": '',
      "insertedOn": ''
    }
  }

  getSteps() {
    return this.steps;
  }

  setSteps(obj) {
    this.steps = obj;
  }

  getClient() {
    return this.applicationData;
  }

  setClient(client) {
    this.applicationData = client;
  }



}
