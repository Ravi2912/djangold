import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageRunOcrPassportComponent } from './page-run-ocr-passport.component';

describe('PageRunOcrPassportComponent', () => {
  let component: PageRunOcrPassportComponent;
  let fixture: ComponentFixture<PageRunOcrPassportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageRunOcrPassportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageRunOcrPassportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
