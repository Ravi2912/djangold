import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'lodash';
import { Client } from '../client.interfaces';
import { ClientService } from '../client.service';
import { staggerIn, blockStagger, containerFade } from '../../app.animations';

declare var UIkit: any;

@Component({
  selector: 'app-page-run-ocr-passport',
  templateUrl: './page-run-ocr-passport.component.html',
  styleUrls: ['./page-run-ocr-passport.component.scss'],
  animations: [staggerIn, blockStagger, containerFade],
  host: {
    '[@staggerIn]': '',
    '[@blockStagger]': '',
    '[@containerFade]': ''
  }
})
export class PageRunOcrPassportComponent implements OnInit {

  tempImage: any;
  files: [''];
  client: Client;
  currentItem: any = "";
  barValue: number = 0;
  barMax: number = 0;
  loadingOCR = true;
  clientLoaded = false;

  constructor(private http: HttpClient, private clientService: ClientService, private router: Router, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.client = this.clientService.getClient();
  }

  ngOnChanges() {
    
  }

  browseFile(element) {
    var selectElement = document.querySelector(element);
    this.files = selectElement.files;
    this.currentItem = this.files[0];

    UIkit.upload('.js-upload', {

      progress: (e) => {
        this.barMax = e.total;
        this.barValue = e.loaded;
      },

      loadEnd: (e) => {
        this.barMax = e.total;
        this.barValue = e.loaded;
      },

      completeAll: () => {
        setTimeout(function () {
        }, 2000);
      }
    });
    this.encodeImageFileAsURL(this.currentItem)
  }

  runOCR = function () {

    this.loadingOCR = false;
    var currentItem = this.currentItem;

    this.client.customerId = 629;

    // TO DO 
    // problem because on this side we don't know which number's can be used for id
    // not all numbers work
    // copy from previous version bellow
    // this.client.customerId = Math.floor(10000 + Math.random() * 90000);

    this.http.post('https://finlabs-neo.synechron.net/onboard/',
      {
        'document_type': 'id_proof',
        'base64_string': this.tempImage,
        'customerId': this.client.customerId
      })
      .subscribe(
        data => {
          let arr = _.map(data, (elm, k) => {
            return [k, elm]
          });
          this._clientMapper(arr);
          this.loadingOCR = true;
          this.clientLoaded = true;
          
        },
        error => {
          
        }
      );
  };

  encodeImageFileAsURL(file) {
    var reader = new FileReader();
    reader.onloadend = () => {
      this.tempImage = reader.result;
    }
    reader.readAsDataURL(file);
  }

  _clientMapper(data) {
    this.client["DOB CD Verification"] = this._getKeyValue('DOB CD Verification', data)
    this.client["Passport No CD Verification"] = this._getKeyValue('Passport No CD Verification', data)
    this.client["Date of Birth"] = this._getKeyValue('Date of Birth', data)
    this.client["Date of Expiry"] = this._getKeyValue('Date of Expiry', data)
    this.client["Document Type"] = this._getKeyValue('DocumentType', data)
    this.client["Issuing Country/Organisation"] = this._getKeyValue('Issuing Country/Organisation', data)
    this.client["Passport Number"] = this._getKeyValue('Passport Number', data)
    this.client["Nationality"] = this._getKeyValue('Nationality', data)
    this.client["Name"] = this._getKeyValue("Person's Name", data)
    this.client["Sex"] = this._getKeyValue('Sex', data)
    this.client["idImage"] = this._getKeyValue('idImage', data)
    this.client["Date of Expiry CD Verification"] = this._getKeyValue('Date of Expiry CD Verification', data)
  }

  _getKeyValue(key, list) {
    let elm = list.filter((e) => {
      if (e && key) {
        return e[0].toLowerCase() == key.toLowerCase()
      }
    })[0];

    if (elm) {
      return elm[1];
    }
  }

  deleteImage() {
    this.tempImage = "";
    this.currentItem = "";
  }

  submitClient(client) {
    this.client = client;
    this.clientService.setClient(this.client);
    if(this.client["Name"]){
      this.bindPersonNames();
    }    
    let steps = this.clientService.getSteps();
    steps[this.route.snapshot.data.step].completed = true;
    this.clientService.setSteps(steps);

    this.router.navigateByUrl('client/ocr-slip');
  };

  bindPersonNames() {
    let nameArray: any = this.client["Name"].split(" ")
    let middleNameArray: any = [];
    let i: any;

    for (i = 1; i < nameArray.length; i++) {
      if (i < String(nameArray.length - 1)) {
        middleNameArray.push(nameArray[i])

      }
    }

    this.client["First Name"] = nameArray[0]
    this.client["Last Name"] = nameArray[nameArray.length - 1]
    this.client["Middle Name"] = middleNameArray
  }

  triggerFalseClick() {
    let browseComp = document.getElementById('browseComp');
    browseComp.click();
  }
}