import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageRunOcrSlipComponent } from './page-run-ocr-slip.component';

describe('PageRunOcrSlipComponent', () => {
  let component: PageRunOcrSlipComponent;
  let fixture: ComponentFixture<PageRunOcrSlipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageRunOcrSlipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageRunOcrSlipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
