import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import _ from 'lodash';
import { Client } from '../client.interfaces';
import { ClientService } from '../client.service';
import { staggerIn, blockStagger, containerFade } from '../../app.animations';

declare var UIkit: any;

@Component({
  selector: 'app-page-run-ocr-slip',
  templateUrl: './page-run-ocr-slip.component.html',
  styleUrls: ['./page-run-ocr-slip.component.scss'],
  animations: [staggerIn, blockStagger, containerFade],
  host: {
    '[@staggerIn]': '',
    '[@blockStagger]': '',
    '[@containerFade]': ''
  }
})
export class PageRunOcrSlipComponent implements OnInit {

  tempImage: any;
  files: [''];
  client: Client;
  currentItem: any = "";
  barValue: number = 0;
  barMax: number = 0;
  loadingOCR = true;
  slipLoaded = false;
  tempList = [];

  constructor(private http: HttpClient, private clientService: ClientService, private router: Router, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.client = this.clientService.getClient();
  }

  browseFile(element) {

    var selectElement = document.querySelector(element);
    this.files = selectElement.files;
    this.currentItem = this.files[0];

    UIkit.upload('.js-upload', {

      progress: (e) => {
        this.barMax = e.total;
        this.barValue = e.loaded;
      },

      loadEnd: (e) => {
        this.barMax = e.total;
        this.barValue = e.loaded;
      },

      completeAll: () => {
        setTimeout(() => {
        }, 2000);
       alert('Upload Completed');
      }
    });
    this.encodeImageFileAsURL(this.currentItem)
  }

  runOCR = function () {
    this.loadingOCR = false;
    var currentItem = this.currentItem;

    // TO DO 
    // problem because on this side we don't know which number's can be used for id
    // not all numbers are supported
    // client id which is supported: 629
    // copy from previous version bellow
    // this.client.customerId = Math.floor(10000 + Math.random() * 90000);

    this.http.post('https://finlabs-neo.synechron.net/onboard/',
      {
        'document_type': 'salary_proof',
        'base64_string': this.tempImage,
        'customerId': this.client.customerId
      })
      .subscribe(
        data => {
          let arr = _.map(data, (elm, k) => {
            return [k, elm]
          });
          this._clientMapper(arr);
          this.loadingOCR = true;
          this.slipLoaded = true;
          
        },
        error => {
          console.log("Request OCR scan error ocucred ", error);
        }
      );
  };

  encodeImageFileAsURL(file) {
    var reader = new FileReader();
    reader.onloadend = () => {
      this.tempImage = reader.result;
    }
    reader.readAsDataURL(file);
  }

  _clientMapper(data) {
    this.client["Name"] = this._getKeyValue('Name', data)
    this.client["City"] = this._getKeyValue('City', data)
    this.client["State"] = this._getKeyValue('State', data)
    this.client["Company Name"] = this._getKeyValue('Company Name', data)
    this.client["Salary"] = this._getKeyValue('Salary', data)
    this.client["Designation"] = this._getKeyValue('Designation', data)
    this.client["Country"] = this._getKeyValue('Country', data)
    this.client["Given Address"] = this._getKeyValue('Given Address', data)
    this.client["Address To HSBC"] = this._getKeyValue('Address To HSBC', data)
    this.client["Clearance Letter Clause"] = this._getKeyValue('Clearance Letter Clause', data)
    this.client["End of Benefits Clause"] = this._getKeyValue('End of Benefits Clause', data)
    this.client["Notification Clause"] = this._getKeyValue('Notification Clause', data)
    this.client["Salary Transfer Clause"] = this._getKeyValue('Salary Transfer Clause', data)
  }

  _getKeyValue(key, list) {
    let elm = list.filter((e) => {
      if (e && key) {
        return e[0].toLowerCase() == key.toLowerCase()
      }
    })[0];

    if (elm) {
      return elm[1];
    }
  }

  deleteImage(image) {
    this.tempImage = "";
    this.currentItem = "";
  }

  submitClient(client) {
    this.client = client;
    this.clientService.setClient(this.client);

    // this.tempList.push(this.client);

    // debugger;

    // this.http.post('https://finlabs-neo.synechron.net/onboard/', {document_type:"data_audit",  audit_data : this.tempList })
    // .subscribe(
    //   data => {

    //     // debugger;
    //     // return data;
    //     console.log("Request OCR scan finished successfully!");
    //   },
    //   error => {
    //     console.log("Request OCR scan error ocucred ", error);
    //   }
    // );


    let steps = this.clientService.getSteps();
    steps[this.route.snapshot.data.step].completed = true;
    this.clientService.setSteps(steps);

    this.router.navigateByUrl('client/verify');
  }

  triggerFalseClick() {
    let browseComp = document.getElementById('browseComp');
    browseComp.click();
  }
}