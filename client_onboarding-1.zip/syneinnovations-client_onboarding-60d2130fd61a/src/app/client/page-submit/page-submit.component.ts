import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ClientService } from '../client.service';

@Component({
  selector: 'app-page-submit',
  templateUrl: './page-submit.component.html',
  styleUrls: ['./page-submit.component.scss']
})
export class PageSubmitComponent implements OnInit {

  constructor(private clientService: ClientService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {

    let steps = this.clientService.getSteps();
    steps[this.route.snapshot.data.step].completed = true;
    
    this.clientService.setSteps(steps);
  }

}
