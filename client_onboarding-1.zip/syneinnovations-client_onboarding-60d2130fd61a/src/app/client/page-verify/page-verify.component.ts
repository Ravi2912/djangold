import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';

import { staggerIn, blockStagger, containerFade } from '../../app.animations';
import { Client } from '../client.interfaces';
import { ClientService } from '../client.service';

@Component({
  selector: 'app-page-verify',
  templateUrl: './page-verify.component.html',
  styleUrls: ['./page-verify.component.scss'],

  animations: [staggerIn, blockStagger, containerFade],
  host: {
    '[@staggerIn]': '',
    '[@blockStagger]': '',
    '[@containerFade]': ''
  }
})
export class PageVerifyComponent implements OnInit {

  client: Client;

  constructor(private http: HttpClient, private clientService: ClientService, private router: Router, private route: ActivatedRoute, public _DomSanitizer: DomSanitizer) {
  }

  ngOnInit() {
    this.client = this.clientService.getClient();
    

  }

  submitClient(client) {
    this.client = client;
    this.clientService.setClient(this.client);
    this.client.document_type = 'form_audit';
    this.client['Passport No CD Verification'] = "Accepted";

    this.http.post('https://finlabs-neo.synechron.net/onboard/', this.client)
      .subscribe(
        data => {
          
        },
        error => {
          console.log("Request OCR scan error ocucred ", error);
        }
      );

    let steps = this.clientService.getSteps();
    steps[this.route.snapshot.data.step].completed = true;
    this.clientService.setSteps(steps);

    this.router.navigateByUrl('client/submit');
  }
}