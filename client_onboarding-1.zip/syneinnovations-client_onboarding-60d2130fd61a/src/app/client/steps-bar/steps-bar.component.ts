import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';
import { ActivatedRoute } from '@angular/router';
import { staggerIn, blockStagger, containerFade } from '../../app.animations';

@Component({
  selector: 'app-steps-bar',
  templateUrl: './steps-bar.component.html',
  styleUrls: ['./steps-bar.component.scss'],
  animations: [staggerIn, blockStagger, containerFade],
  host: {
    '[@staggerIn]': '',
    '[@blockStagger]': '',
    '[@containerFade]': ''
  }
})
export class StepsBarComponent implements OnInit {
  steps: any;
  activeStep: number = this.route.snapshot.data.step;
  constructor(private clientService: ClientService, private route: ActivatedRoute) {
    this.steps = this.clientService.getSteps();
  }

  ngOnInit() {
  }
  ngOnChanges() {
  }

}
