//export var CreditRiskAPI = 'http://demo2515443.mockable.io';
export var CreditRiskAPI = 'http://synainn.eastus.cloudapp.azure.com:7600/credit_risk';

export var CustomerComplaintsAPI = 'http://synainn.eastus.cloudapp.azure.com:8999';

export var VisualResearchAPI = 'http://5bb28dcf77063c0014a7d242.mockapi.io/visual-research'; //TODO
//export var VisualResearchAPI = 'http://synainn.eastus.cloudapp.azure.com:8323/dashboard'; //TODO

export var LoginAPI = 'http://synainn.eastus.cloudapp.azure.com/api';
