import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NotFoundComponent } from './not-found/not-found.component';
import { AuthGuardService } from './services/auth-guard.service';
import { PageSplashscreenComponent } from './page-splashscreen/page-splashscreen.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
    {
        path: 'login',
        component: LoginComponent, 
        data: {depth: 0, state: 'login'}
    },
    {
        path: '',
        component: PageSplashscreenComponent, 
        data: {depth: 0, state: 'splashscreen'}
    },
    {
        path: 'admin',
     //   canActivate: [AuthGuardService],
        loadChildren: '../admin/admin.module#AdminModule', 
        data: {depth: 1, state: 'admin'}
    },
    {
        path: 'client',
   //     canActivate: [AuthGuardService],
        loadChildren: '../client/client.module#ClientModule', 
        data: {depth: 1, state: 'client'}
    },
    {
        path: '**',
        component: NotFoundComponent, 
        data: {depth: 0}
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class CoreRoutingModule { }
