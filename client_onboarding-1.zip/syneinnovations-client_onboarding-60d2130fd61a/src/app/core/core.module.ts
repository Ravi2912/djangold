import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { CoreRoutingModule } from './core-routing.module';
import { NotFoundComponent } from './not-found/not-found.component';
import { AuthenticationService } from './services/authentication.service';
import { AuthGuardService } from './services/auth-guard.service';
import { PageSplashscreenComponent } from './page-splashscreen/page-splashscreen.component';
import {LoginComponent} from './login/login.component';

@NgModule({
    imports: [
        CommonModule,
        HttpClientModule,
        CoreRoutingModule,
        FormsModule,
        SharedModule,
    ],
    declarations: [
        PageSplashscreenComponent,
        NotFoundComponent,
        LoginComponent,
    ],
    exports: [
        RouterModule,
    ],
    providers: [
        AuthenticationService,
        AuthGuardService
    ]
})
export class CoreModule { }
