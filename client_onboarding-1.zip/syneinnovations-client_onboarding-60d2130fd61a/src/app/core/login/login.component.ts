import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
    error: boolean;
    constructor(private authentication: AuthenticationService, private router: Router) { }

    ngOnInit() {

    }

    login(username, password) {
        
        // this.authentication.login(username, password);
        // this.error = localStorage.getItem("error");
        // debugger;


        this.authentication.login(username, password)
        // .catch(error => {
        //     this.error = true;
        // });
           
    }

    keyDownFunction(event, form) {
        if (event.keyCode == 13) {
            //alert('you just clicked enter');
            // rest of your code
            form.ngSubmit.emit();
        }
    }

}
