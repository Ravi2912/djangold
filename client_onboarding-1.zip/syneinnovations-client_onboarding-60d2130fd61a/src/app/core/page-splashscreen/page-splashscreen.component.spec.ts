import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageSplashscreenComponent } from './page-splashscreen.component';

describe('PageSplashscreenComponent', () => {
  let component: PageSplashscreenComponent;
  let fixture: ComponentFixture<PageSplashscreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageSplashscreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageSplashscreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
