import { Component, OnInit } from '@angular/core';
import { staggerIn, blockStagger, containerFade } from '../../app.animations';

@Component({
  selector: 'app-page-splashscreen',
  templateUrl: './page-splashscreen.component.html',
  styleUrls: ['./page-splashscreen.component.scss'],
  animations: [staggerIn, blockStagger, containerFade],
  host: {
    '[@staggerIn]': '',
    '[@blockStagger]': '',
    '[@containerFade]': ''
  }
})
export class PageSplashscreenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
