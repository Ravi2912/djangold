import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import "rxjs/add/operator/map";
import axios from 'axios';
import { LoginAPI } from '../../config/api';

@Injectable()
export class AuthenticationService {
    token: any;
    tokenKey: string = "a6smm_utoken"

    //Previous Code
    // token = {
    //     refresh_token: 'refreshtokencode',
    //     exp: new Date((new Date().getDate() + 1)),
    //     access_token: {
    //         username: 'user',
    //         roles: ['Admin', 'RegisteredUser', 'Super User']
    //     }
    // };

    constructor(private router: Router) { }

    // login(username, password) {
    //     if (username && password) {
    //         this.setToken(this.token);
    //         this.router.navigate(['admin', 'dashboard']);
    //     }
    // }

    login(username, password) {
        var credentials = {
            username: username,
            password: password
        };
        
        if(credentials.username == 'demo' && credentials.password == 'demo@123'){
            localStorage.setItem("userName", credentials.username);
                localStorage.setItem("userEmail", credentials.password);

                this.token = {
                    refresh_token: 'refreshtokencode',
                    exp: new Date((new Date().getDate() + 1)),
                    access_token: {
                        username: credentials.username,
                        roles: ['Admin', 'RegisteredUser', 'Super User']
                    }
                };
                this.setToken(this.token);
                //this.router.navigate(["admin", "dashboard"]);
                this.router.navigateByUrl(`/`);
        }


        //let loginURL = LoginAPI + '/auth/login';
        // return axios({
        //     method: "post",
        //     url: loginURL,
        //     data: credentials
        // })
        //     .then(response => {
        //         localStorage.setItem("userName", response.data.firstname + ' ' + response.data.lastname);
        //         localStorage.setItem("userEmail", response.data.email);

        //         this.token = {
        //             refresh_token: 'refreshtokencode',
        //             exp: new Date((new Date().getDate() + 1)),
        //             access_token: {
        //                 username: response.data.username,
        //                 roles: ['Admin', 'RegisteredUser', 'Super User']
        //             }
        //         };
        //         this.setToken(this.token);
        //         this.router.navigate(["admin", "dashboard"]);
        //         // return response.data;
        //     });
    }

    logout() {
        localStorage.clear();
        this.removeToken();
        this.router.navigate(['login']);
        let logoutURL = LoginAPI + "/auth/logout";
        // return axios({
        //     method: "get",
        //     url: logoutURL
        // })
        //     .then(response => {
        //         localStorage.clear();
        //         this.removeToken();
        //         this.router.navigate(['login']);
        //     })
        //     .catch(error => {
        //         console.log("Error occurred!!", error);
        //     })

    }

    getToken() {
        return JSON.parse(localStorage.getItem(this.tokenKey));
    }

    setToken(token) {
        localStorage.setItem(this.tokenKey, JSON.stringify(token));
    }

    getAccessToken() {
        return JSON.parse(localStorage.getItem(this.tokenKey))['access_token'];
    }

    isAuthenticated() {
        let token = localStorage.getItem(this.tokenKey);

        if (token) {
            return true;
        }
        else {
            return false;
        }
    }

    refreshToken() {
        this.token.exp = new Date((new Date().getDate() + 1));
        this.setToken(this.token);
    }

    removeToken() {
        localStorage.removeItem(this.tokenKey);
    }

}
