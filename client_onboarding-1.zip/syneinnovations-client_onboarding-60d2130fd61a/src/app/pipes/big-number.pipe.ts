import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'bigNumber'
    })
    
    export class BigNumber implements PipeTransform {
        transform(input: number): any {
    
    
        let price: number = input;
    
            if (price / 1000 > 1) {
                if (price / 1000000 >= 1) {
                    return parseFloat((price / 1000000).toFixed(3)) + "M";
                } else {
                    return parseFloat((price / 1000).toFixed(2)) + "K";
                }
            } else {
                return price;
            }
        }
    }

    