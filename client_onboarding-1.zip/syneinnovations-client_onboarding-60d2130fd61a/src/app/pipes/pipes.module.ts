import { NgModule, ModuleWithProviders } from '@angular/core';
import {CommonModule} from '@angular/common';
 

import {BigNumber} from '../pipes/big-number.pipe';
 
 
 
 

@NgModule({
  declarations: [
    BigNumber
   
  ],
  imports: [
    
    CommonModule,
     
  ],
  providers: [],
  bootstrap: [],
  exports:[ 
    BigNumber
  ]
})
export class PipesModule { 

}
