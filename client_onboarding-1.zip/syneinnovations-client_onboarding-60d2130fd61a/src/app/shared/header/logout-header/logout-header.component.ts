import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logout-header',
  templateUrl: './logout-header.component.html',
  styleUrls: ['./logout-header.component.scss']
})
export class LogoutHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
