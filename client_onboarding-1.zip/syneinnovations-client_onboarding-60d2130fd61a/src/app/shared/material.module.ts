import { NgModule } from '@angular/core';
import {MatIconModule,MatChipsModule,MatNativeDateModule,MatDatepickerModule,MatProgressSpinnerModule,MatCheckboxModule,MatSelectModule,MatInputModule,MatFormFieldModule,MatSortModule,MatPaginatorModule,MatTableModule,MatButtonModule,MatAutocompleteModule} from '@angular/material';


const modules = [
    // MatButtonModule,
    // MatTableModule,
    // MatPaginatorModule,
    // MatSortModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    // MatCheckboxModule,
    // ,MatProgressSpinnerModule,
    // MatDatepickerModule,
    // MatNativeDateModule,
    // MatChipsModule,
    // MatIconModule,
    MatAutocompleteModule]

@NgModule({
    imports:modules, 
    exports:modules
})

export class MaterialModule{

}