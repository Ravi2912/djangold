import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { MaterialModule } from './material.module';
import { PipesModule } from '../pipes/pipes.module';
import { LogoutHeaderComponent } from './header/logout-header/logout-header.component';

@NgModule({
  declarations: [
     LogoutHeaderComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    PipesModule
  ],
  providers: [],
  bootstrap: [],
  exports: [ MaterialModule, LogoutHeaderComponent]
})
export class SharedModule { }
