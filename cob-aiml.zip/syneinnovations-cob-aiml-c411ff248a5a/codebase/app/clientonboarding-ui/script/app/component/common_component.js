/**
 * 
 * Finlap - POC - ClientOnboarding
 * 
 */
;(function() {


  /**
   * Definition of the main app module and its dependencies
   */
  angular
    .module('ClientOnboarding')
	.directive("kycUserData", function () {
	    return {
	    restrict: 'E',
        scope:{
            responseData: '=',
            readMode: '='
        },
	    templateUrl:"script/app/component/common-html/kyc-data.html",
	    link: function($scope, element, attrs) {
	      //$scope.readMode = $scope.readMode || false;
	    }
	  };
	})
})();