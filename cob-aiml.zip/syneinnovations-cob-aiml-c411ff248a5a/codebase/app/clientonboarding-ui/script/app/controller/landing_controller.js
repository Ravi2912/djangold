/**
 * 
 *  ClientOnboarding - Create Leads Controller
 * 
 */
;(function() {


  /**
   * Angular Dependencies: $scope, $http
     Service Dependencies: OCRData: Contain utility props and methods 
   */
  angular
    .module('ClientOnboarding')
    .controller('landingPageController', function($scope, $http, OCRData, $uibModal, $state, $rootScope, $document, ClientAPI){
      //hold context
      var landingPage = this;

      /*** open model action **/
      landingPage.open = function (size) {
        var parentElem = angular.element($document[0].querySelector('.landing-page'));

        //create instance
        var modalInstance = $uibModal.open({
          animation: true,
          ariaLabelledBy: 'login',
          ariaDescribedBy: 'login-body',
          templateUrl: 'loginModel.html',
          controller: 'LoginInstanceCtrl',
          controllerAs: '$ctrl',
          size: 'lg',
          appendTo: parentElem
        });

        //call back method to trigger when user perform action
        modalInstance.result.then(function (clickItem) {
          $rootScope.userType = clickItem;
          if(clickItem === 'admin'){
              $state.go('leads')
          }else{
            $state.go('createleads')
          }
        }, function () {
          console.log('Modal dismissed at: ' + new Date());
        });
      };

    })
    .controller('LoginInstanceCtrl', function ($uibModalInstance) {
      var $ctrl = this;
      $ctrl.invalidCredentials = false;
      //login method 
      $ctrl.login = function (buttonClicked) {
        if(buttonClicked === 'admin'){
          if($ctrl.username === 'admin' && $ctrl.password === 'admin'){
            $uibModalInstance.close('admin');
            //valid credentials
            $ctrl.invalidCredentials = false;
          }else{
            //invalid credentials
            $ctrl.invalidCredentials = true;
          }
        }else{
           $uibModalInstance.close('general');
        }
      };
      //cancel method
      $ctrl.cancel = function () {
        $uibModalInstance.dismiss('cancel');
      };
    });

})();