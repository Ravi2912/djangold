/**
 * 
 *  ClientOnboarding - Create Leads Controller
 * 
 */
;(function() {


  /**
   * Angular Dependencies: $scope, $http
     Service Dependencies: OCRData: Contain utility props and methods 
   */
  angular
    .module('ClientOnboarding')
    .controller('leadsController', function($scope, $http, OCRData, $state, $uibModal, $document, Notification, ClientAPI){
      //hold context
      var leads = this;

      //store the current page reference
      leads.currentPage = $state.current.name;
      //default list index
      leads.currentIndex = 0;
      /*** get individual list Data - based on user click"**/
      leads.getItemData = function(customerId){
         
          //prepare request process object
          var getItem = {
           method: 'POST',
           url: ClientAPI.name+'/admins/details',
           data: {customerId: customerId}
          };

          //trigger request
          $http(getItem).then(function(response){
            leads.itemResponse = response.data;
          }, function(error){
            console.log(error);
          });
      };

      
      /*** Get Leads List - List of items"**/
      leads.getLeads = function(){
          //prepare request process object
          var getLeads = {
           method: 'GET',
           url: ClientAPI.name+'/admins/'+leads.currentPage
          };

          //trigger request
          $http(getLeads).then(function(response){
            //store the list items
            leads.listItems = response.data;
            if(response.data.length){
              leads.getListDetails(0, leads.listItems[0].customerId);
            }
          }, function(error){


          });
      };

      //get the list data
      leads.getLeads();


      leads.getListDetails = function(index, customerId){
        //default list index
        leads.currentIndex = index;
        leads.getItemData(customerId);
      };

      leads.getDetailImage = function(customerId, document_type){
          //prepare request process object
          var detailImage = {
           method: 'POST',
           url: ClientAPI.name+'/admins/image',
           data: {customerId: customerId, document_type: document_type}
          };

          //trigger request
          $http(detailImage).then(function(response){
            console.log(response);
            loadImage(response.data.image);
          }, function(error){
            console.log(error);
          });

          function loadImage(imagedata){
              var parentElem = angular.element($document[0].querySelector('.main-leads-container'));

              var modalInstance = $uibModal.open({
                animation: true,
                ariaLabelledBy: 'modal',
                ariaDescribedBy: 'modal-body',
                templateUrl: 'ImageModel.html',
                controller: 'ModelInstanceCtrl',
                controllerAs: '$ctrl',
                size: 'lg',
                appendTo: parentElem,
                resolve: {
                  imagedata: function () {
                    return imagedata;
                  }
                }
              });

              modalInstance.result.then(function (clickItem) {
               console.log('test')
              }, function () {
                console.log('Modal dismissed at: ' + new Date());
              });


          }
      };

      leads.processRequest = function(customerId, document_type){
          //prepare request process object
          var processRequest = {
           method: 'POST',
           url: ClientAPI.name+'/admins/'+document_type,
           data: {customerId: customerId}
          };

          //trigger request
          $http(processRequest).then(function(response){
            //get the list data
            leads.getLeads();
            Notification.success({message: 'Request is successfully submitted.', positionX: 'center', delay: 4000});
            //reset individual response data
            leads.itemResponse = {};
            console.log(response);
          }, function(error){
            console.log(error);
          });
      };

    })
    .controller('ModelInstanceCtrl', function ($uibModalInstance, imagedata) {
      var $ctrl = this;
      $ctrl.imagedata = imagedata;
      $ctrl.cancel = function () {
        $uibModalInstance.dismiss('cancel');
      };
    });

})();