import cv2
import numpy
from statistics import median, mean
import numpy as np
import kmean

class mserImageCrop():

    def __init__(self):
        pass

  
    def getThresh(self, img):
        ls = []
        h,w = img.shape
        for x in range(h):
            for y in range(w):
                ls.append(img[x][y])
                
                
        mu = kmean.find_centers(np.array(ls),2)
        return mean(mu)



    def loadImg(self, image):

        self.image = image
        try:
            self.gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
       	except:
            self.gray_image = image 
        self.mser = cv2.MSER()
        self.Height, self.Width = self.gray_image.shape
        self.resizingFactor = 1.0
        self.croppedGrayImage = None
        self.croppedImage = None
        self.resizedCroppedGrayImage = None
        self.resizedCroppedImage = None
        self.croppedmrzImage = None
        self.croppedmrzGrayImage = None 
        self.idPhotoImage = None


    def scaleResizingFactor(self, medianHeight):

        if medianHeight >= 20:
            self.resizingFactor =  1.0

        else:
            self.resizingFactor = round(1.2 + (14.4/float(medianHeight)), 1)

    def ResizeGrayImage(self):

        if self.croppedGrayImage is not None:
            self.resizedCroppedGrayImage = cv2.resize(self.croppedGrayImage, (0,0), fx=self.resizingFactor, fy=self.resizingFactor)

    def ResizeImage(self):

        if self.croppedImage is not None:
            self.resizedCroppedImage = cv2.resize(self.croppedImage, (0,0), fx=self.resizingFactor, fy=self.resizingFactor)


    def cropImage(self):

        mser_areas = self.mser.detect(self.gray_image)

        height_mat = []
        width_mat = []
        mser_rects = []
        for mser_area in mser_areas:
            x1 = min(mser_area, key=lambda x: x[0])[0]
            x2 = max(mser_area, key=lambda x: x[0])[0]
            y1 = min(mser_area, key=lambda x: x[1])[1]
            y2 = max(mser_area, key=lambda x: x[1])[1]

            mser_rects.append([x1, x2, y1, y2])

            height_mat.append(y2 - y1)
            width_mat.append(x2 - x1)

        if len(mser_areas):
            size_thresh = min(median(height_mat), median(width_mat))
            medianHeight =  median(height_mat)
            medianWidth = median(width_mat)
            self.scaleResizingFactor(medianHeight)
            min_x, min_y, max_x, max_y = [100000, 100000, 0, 0]
            flag_cropped = False
            for rect in mser_rects:
                if rect[1] - rect[0] > size_thresh * 0.7 and rect[1] - rect[0] < size_thresh * 3 and rect[3] - rect[2] > size_thresh * 0.7 and rect[3] - rect[2] < size_thresh * 3:
                    min_x = min(min_x, rect[0])
                    max_x = max(max_x, rect[1])
                    min_y = min(min_y, rect[2])
                    max_y = max(max_y, rect[3])
                    flag_cropped = True

            if flag_cropped:
                min_x = max(min_x - 2, 0)
                max_x = min(max_x + 2, self.Width)
                min_y = max(min_y - 2, 0)
                max_y = min(max_y + 2, self.Height)
                self.croppedGrayImage = self.gray_image[min_y:max_y, min_x:max_x]
                self.croppedImage = self.image[min_y:max_y, min_x:max_x]

                # cv2.imshow('cropped image', self.croppedImage)
                # cv2.waitKey()
                # print 'cropped : ',min_x, max_x, min_y, max_y
        else:
            self.croppedGrayImage = self.gray_image
            self.croppedImage = self.image


    def halfImage(self):

        if self.croppedImage is not None:
            height, width, channel = self.croppedImage.shape
            if height > width:
                self.croppedImage = self.croppedImage[height/2-1:,:]

        if self.croppedGrayImage is not None:
            height, width = self.croppedGrayImage.shape
            if height > width:
                self.croppedGrayImage = self.croppedGrayImage[height/2-1:,:]

    def iddocMrzSectionProcess(self):

        if self.croppedImage is not None:
            height, width, channel = self.croppedImage.shape
            self.croppedImage = self.croppedImage[3*height/4:,:]

        if self.croppedGrayImage is not None:
            height, width = self.croppedGrayImage.shape
            self.croppedGrayImage = self.croppedGrayImage[3*height/4:,:]


    def mserBinariseImage(self):


        height, width = self.croppedGrayImage.shape
        binImg = np.zeros((height,width,1), np.uint8)


        mser_areas = self.mser.detect(self.croppedGrayImage)

        mser_rects = []

        for mser_area in mser_areas:
            x1 = min(mser_area, key=lambda x:x[0])[0]
            x2 = max(mser_area, key=lambda x:x[0])[0]
            y1 = min(mser_area, key=lambda x:x[1])[1]
            y2 = max(mser_area, key=lambda x:x[1])[1]
            
            mser_rects.append([x1,x2,y1,y2])



        for rect in mser_rects:
    

            x1,x2,y1,y2 = rect
            # print x1,x2,y1,y2
            tempImg = self.croppedGrayImage[y1:y2,x1:x2]
            # cv2.imshow('temp', tempImg)
            # cv2.waitKey()
            thresh = self.getThresh(tempImg)
            
            for y in range(y1,y2+1):
                for x in range(x1, x2+1):
                    if self.croppedGrayImage[y][x] > thresh:
                        binImg[y][x] = 2
                    else:
                        binImg[y][x] = 250

        self.croppedGrayImage = binImg


    def scanIdImage(self):

        try:
            file_r = open('prerequisiteData/haarcascade_frontalface_default.xml', 'r')
            print 'file exists'
        except:
            print 'file not found'

        faceCascade = cv2.CascadeClassifier('prerequisiteData/haarcascade_frontalface_default.xml')
        img = self.image
        grayImg = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # print "was here", img[0:10]
        faces = faceCascade.detectMultiScale(
            grayImg,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30),
            flags = cv2.cv.CV_HAAR_SCALE_IMAGE
        )
        print faces
        for (x, y, w, h) in faces:
            cv2.rectangle(img, (x-25, y-40), (x+w+30, y+h+50), (0, 255, 0), 2)
            self.idPhotoImage = img[(y-40):(y+h+50), (x-25):(x+w+30)]
        # img = cv2.resize(img,(700,700))
        # cropped_imge = img[(y-40):(y+h+50), (x-25):(x+w+30)]


    def sharpenImage(self):

        
        # if self.croppedImage is not None:

        #     self.croppedImage = cv2.adaptiveThreshold(self.croppedImage,255,cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY,11,2)
        #     cv2.imshow('sharp', self.croppedImage)

        if self.croppedGrayImage is not None:

            ret, self.croppedGrayImage = cv2.threshold(self.croppedGrayImage,127,255,cv2.THRESH_BINARY)

