from django.db import models


# Create your models here.

# Contains all the elements that any of the 3 documents can have. To be passed to UI and UI should be able to render
# based upon document type.
class MasterData:
    def __init__(self, document_type, document_number, first_name, last_name, date_of_birth, date_of_issue,
                 date_of_expiry, address, zip_code, salary):
        self.document_type = document_type
        self.document_number = document_number
        self.first_name = first_name
        self.last_name = last_name
        self.date_of_birth = date_of_birth
        self.date_of_issue = date_of_issue
        self.date_of_expiry = date_of_expiry
        self.address = address
        self.zip_code = zip_code
        self.salary = salary


# Contains all the fields corresponding to an Identity document.
class IdProof:
    customer_id = ''
    document_number = ''
    first_name = ''
    last_name = ''
    date_of_birth = ''
    date_of_issue = ''
    date_of_expiry = ''

    def __init__(self, document_number, first_name, last_name, date_of_birth, date_of_issue, date_of_expiry):

        self.document_number = document_number
        self.first_name = first_name
        self.last_name = last_name
        self.date_of_birth = date_of_birth
        self.date_of_issue = date_of_issue
        self.date_of_expiry = date_of_expiry


# Contains all the fields corresponding to an address document.
class AddressProof:
    customer_id = ''
    document_number = ''
    first_name = ''
    last_name = ''
    address = ''
    zipcode = ''
    date_of_issue = ''
    date_of_expiry = ''

    def __init__(self, document_number, first_name, last_name, address, zipcode, date_of_issue, date_of_expiry):

        self.document_number = document_number
        self.first_name = first_name
        self.last_name = last_name
        self.address = address
        self.zipcode = zipcode
        self.date_of_issue = date_of_issue
        self.date_of_expiry = date_of_expiry


# Contains all the fields corresponding to a salary document.
class SalaryProof:
    customer_id = ''
    salary = ''
    first_name = ''
    last_name = ''
    date = ''
    account_number = ''
    company = ''

    def __init__(self, first_name, last_name, salary, date, account_number, company):

        self.salary = salary
        self.first_name = first_name
        self.last_name = last_name
        self.date = date
        self.account_number = account_number
        self.company = company


# Data to be displayed in the form.
class FormData:
    customer_id = ''
    salary = ''
    first_name = ''
    last_name = ''

    def __init__(self, first_name, last_name, salary):

        self.salary = salary
        self.first_name = first_name
        self.last_name = last_name


class InputData:
    customer_id = ''
    document_type = ''
    base64_string = ''

    def __init__(self, document_type, base64_string):

        self.document_type = document_type
        self.base64_string = base64_string
