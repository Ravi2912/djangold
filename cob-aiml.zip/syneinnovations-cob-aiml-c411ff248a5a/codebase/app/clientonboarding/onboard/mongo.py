from pymongo import MongoClient;


class MongoConnector:

    @staticmethod
    def get_connection(db_name, collection_name):
        client = MongoClient();
        db = client[db_name];
        collection = db[collection_name];
        return collection;