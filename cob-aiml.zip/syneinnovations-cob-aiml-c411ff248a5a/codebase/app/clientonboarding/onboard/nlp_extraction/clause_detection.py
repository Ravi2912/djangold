from nltk.stem.wordnet import WordNetLemmatizer
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk import pos_tag
from nltk.corpus import wordnet

class ClauseDetection():

    ALL_VERB_TAGS = ['VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ']
    PERSONAL_NOUN_TAGS = ['NNP', 'NNPS']
    PRONOUN_TAGS = ['PRP', 'PRP$']
    PREPOSITION_TAGS = ['IN']

    UNI_LEMMATIZER = WordNetLemmatizer()

    @staticmethod
    def WUP_compare(word_a, word_b, property, thresh=0.7):

        word_a = ClauseDetection.UNI_LEMMATIZER.lemmatize(word_a, property)

        try:
            w1 = wordnet.synset('.'.join([word_a, property, '1']))
            w2 = wordnet.synset('.'.join([word_b, property, '1']))

            if w2.wup_similarity(w1) >= thresh:
                return True
            else:
                return False
        except:
            return False

    @staticmethod
    def is_Noun(tag):
        if tag[1] == 'NN' or tag[1] == 'NNS':
            return True
        return False

    @staticmethod
    def is_State(tag, StateList):
        if tag[1] in StateList:
            return True
        return False

    @staticmethod
    def Word_Compare(word_a, word_b, lemm=False):
    
        if lemm:
            word_a = ClauseDetection.UNI_LEMMATIZER.lemmatize(word_a, property)

        if word_a in word_b and len(word_a) >= len(word_b)/2:
            return True
        else:
            return False


    def __init__(self):
        self.raw_data = ""
        self.ref_data = ""
        self.ClauseAnalysis = []

    def load(self, raw_data, ref_data):
        self.raw_data = raw_data
        self.ref_data = ref_data
        self.ClauseAnalysis = []

    @staticmethod
    def get_SetGEN1(tags, compare_Key, compare_Prop, thresh=0.7):

        GEN_score = 0.0
        position = 0
        for tag in tags:
            if ClauseDetection.Word_Compare(tag[0], compare_Key) or ClauseDetection.WUP_compare(tag[0], compare_Key, compare_Prop, thresh):
                GEN_score = 1.0
                # print '->', tag[0], compare_Key
                break
            position += 1
            
        return GEN_score, position

    @staticmethod
    def get_SetGEN2(tags, compare_Key, compare_Prop, searchPROP):

        GEN_score = 0.0
        precur = []
        position = 0
        for i, tag in enumerate(tags):

            if ClauseDetection.WUP_compare(tag[0], compare_Key, compare_Prop):
                # print tag[0]
                GEN_score += 0.7
                position = i
                for pretag in precur[0:min(len(precur), 3)]:

                    if pretag[1] in searchPROP:
                        GEN_score += 0.3

                break
            position = i
            precur = [tag] + precur

        return GEN_score, position

    @staticmethod
    def get_SetD(tags):

        setD_Score = 0.0

        for i, tag in enumerate(tags):
            # print tags[i-1]
            if ClauseDetection.is_State(tag, ClauseDetection.PRONOUN_TAGS) and ClauseDetection.is_State(tags[i-1], ClauseDetection.PREPOSITION_TAGS):   
                setD_Score += 0.8
                # try:
                if ClauseDetection.is_Noun(tags[i+1]):
                    if ClauseDetection.WUP_compare(tags[i+1][0], 'bank', 'n') or ClauseDetection.WUP_compare(tags[i+1][0], 'organisation', 'n'):
                        setD_Score += 0.2
                
                break
    

        return setD_Score

    def getClauseOne(self):

        sents = sent_tokenize(self.ref_data)

        clauseScore = 0.0

        for sent in sents:
            words = word_tokenize(sent)

            tags = pos_tag(words)

            # print tags

            ScoreA, posA = ClauseDetection.get_SetGEN2(tags, 'salary', 'n', ClauseDetection.PRONOUN_TAGS)
            ScoreB1, posB1 = ClauseDetection.get_SetGEN1(tags, 'transfer', 'v')
            ScoreB2, posB2 = ClauseDetection.get_SetGEN1(tags, 'credit', 'v')
            ScoreB = max(ScoreB1, ScoreB2)
            posB = min(posB1, posB2)
            ScoreC, posC = ClauseDetection.get_SetGEN2(tags[posB:], 'account', 'n', ClauseDetection.PRONOUN_TAGS)
            ScoreD, posD = ClauseDetection.get_SetGEN1(tags[posB:], 'maintain', 'v', 0.5)
            ScoreE = ClauseDetection.get_SetD(tags[posB:])

            currentScore = ScoreA * 2 + ScoreB * 2 + ScoreC * 1 + ScoreD * 1 + ScoreE * 2

            clauseScore = max(clauseScore, float(currentScore) / 8)
        # print clauseScore
        # raw_input()


        return clauseScore

    def getClauseTwo(self):

        sents = sent_tokenize(self.ref_data)

        clauseScore = 0.0

        for sent in sents:
            words = word_tokenize(sent)

            tags = pos_tag(words)

            # print tags

            ScoreA, posA = ClauseDetection.get_SetGEN2(tags, 'clearance', 'n', ClauseDetection.PRONOUN_TAGS)
            ScoreB1, posB1 = ClauseDetection.get_SetGEN1(tags[posA:], 'letter', 'n')
            ScoreB2, posB2 = ClauseDetection.get_SetGEN1(tags[posA:], 'certificate', 'n')
            ScoreB3, posB3 = ClauseDetection.get_SetGEN1(tags[posA:], 'certicate', 'n')
            ScoreB = max(ScoreB1, ScoreB2, ScoreB3)
            posB = min(posB1, posB2, posB3)
            ScoreE = ClauseDetection.get_SetD(tags[posA:][posB:])

            currentScore = ScoreA * 2 + ScoreB * 2 + ScoreE * 2

            clauseScore = max(clauseScore, float(currentScore) / 6)
            # print clauseScore
            # raw_input()


        return clauseScore

    def getClauseThree(self):

        sents = sent_tokenize(self.ref_data)

        clauseScore = 0.0

        for ind, sent in enumerate(sents):

            words = word_tokenize(sent)

            tags = pos_tag(words)
            ScoreA, posA = ClauseDetection.get_SetGEN1(tags, 'employment', 'n')
            ScoreB1, posB1 = ClauseDetection.get_SetGEN1(tags, 'cease', 'v')
            ScoreB2, posB2 = ClauseDetection.get_SetGEN1(tags, 'resignation/termination','n')
            ScoreB = max(ScoreB1, ScoreB2)
            posB = min(posB1, posB2)
            ScoreC, posC = ClauseDetection.get_SetGEN1(tags[min(posB, posA):], 'notify', 'v')
            try:
                if ScoreB > 0.5 and ScoreC < 0.5:
                    nextTags = pos_tag(word_tokenize(sents[ind+1]))
                    ScoreC, posC = ClauseDetection.get_SetGEN1(nextTags, 'notify', 'v')
                    
            except:
                print "exception raised in clause three"
                
            # print ScoreA, ScoreB, ScoreC
            # raw_input()
            
                
            currentScore = ScoreA*1 + ScoreB*2 + ScoreC*2
            clauseScore = max(clauseScore, currentScore/5)
        return clauseScore

    def getClauseFour(self):

        sents = sent_tokenize(self.ref_data)

        clauseScore = 0.0

        for ind, sent in enumerate(sents):

            words = word_tokenize(sent)

            tags = pos_tag(words)

            ScoreA, posA = ClauseDetection.get_SetGEN1(tags, 'confirm', 'v')
            ScoreB1, posB1 = ClauseDetection.get_SetGEN1(tags, 'terminal', 'n', 0.87)
            ScoreB2, posB2 = ClauseDetection.get_SetGEN1(tags, 'end-of-service', 'n')
            ScoreB3, posB3 = ClauseDetection.get_SetGEN1(tags, 'resignation/termination', 'n')
            ScoreB = max(ScoreB1, ScoreB2, ScoreB3)
            posB = min(posB1, posB2, posB3)
            ScoreC, posC = ClauseDetection.get_SetGEN1(tags[posB:], 'benefits', 'n')
            
            ScoreD, posD = ClauseDetection.get_SetGEN1(tags[posB:], 'recover', 'v')
            ScoreE, posE = ClauseDetection.get_SetGEN1(tags[posB:], 'due', 'n')
            
            ScoreF, posF = ClauseDetection.get_SetGEN1(tags[posB:], 'forward', 'v')
            
            try:
                if ScoreA+ScoreB+ScoreC >= 2.0 and ScoreD + ScoreE < 1.0:
                    nextTags = pos_tag(word_tokenize(sents[ind+1]))
                    ScoreD, posD = ClauseDetection.get_SetGEN1(nextTags, 'recover', 'v')
                    ScoreE, posE = ClauseDetection.get_SetGEN1(nextTags, 'due', 'n')
                    
                    ScoreF, PosF = ClauseDetection.get_SetGEN1(nextTags[min(posD, posE):], 'forward', 'v')
                    try:
                        if ScoreD+ScoreE >=1.0 and ScoreF<0.5:
                            nextnextTags = pos_tag(word_tokenize(sents[ind+2]))
                            ScoreF, posF = ClauseDetection.get_SetGEN1(nextnextTags, 'forward', 'v')
                            
                    except:
                        print "exception raised in clause 4"
                    
            except:
                print "exception raised in clause 4"
                
            currentScore = ScoreA*1 + ScoreB*2 + ScoreC*2 + ScoreD*1 + ScoreE*2 + ScoreF*1
            # print ScoreA, ScoreB, ScoreC, ScoreD, ScoreE, ScoreF
            clauseScore = max(clauseScore, currentScore/9)

        return clauseScore

    def getClauseAnalysis(self):

        self.ClauseAnalysis = []

        if self.getClauseOne() >= 0.6:
            self.ClauseAnalysis.append(["Salary Transfer Clause", "Present"])
        else:
            self.ClauseAnalysis.append(["Salary Transfer Clause", "Not Present"])

        if self.getClauseTwo() >= 0.6:
            self.ClauseAnalysis.append(["Clearance Letter Clause", "Present"])
        else:
            self.ClauseAnalysis.append(["Clearance Letter Clause", "Not Present"])

        if self.getClauseThree() > 0.6:
            self.ClauseAnalysis.append(["Notification Clause", "Present"])
        else:
            self.ClauseAnalysis.append(["Notification Clause", "Not Present"])

        if self.getClauseFour() >= 0.55:
            self.ClauseAnalysis.append(["End of Benefits Clause", "Present"])
        else:
            self.ClauseAnalysis.append(["End of Benefits Clause", "Not Present"])


