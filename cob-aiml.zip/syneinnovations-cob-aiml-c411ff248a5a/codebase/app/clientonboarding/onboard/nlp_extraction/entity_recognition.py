import re
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk import pos_tag, ne_chunk
from nltk.stem import PorterStemmer, WordNetLemmatizer
from words2num import WordsToNumbers

class EntityRecognition():
    nounList = open('prerequisiteData/DataPDF_NOUNS.txt', 'r').read().split()

    MonthList = ['jan', 'feb', 'mar', 'apr', 'may', 'june', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec', 'january',
                 'february', 'march', 'april', 'june', 'july', 'august', 'september', 'october', 'november', 'december']

    CompensationKeyWords = ['salary', 'compensation', 'remuneration']

    RefCompanyCodeList = ['Inc', 'Co', 'Limited', 'Ltd', 'Inc.', 'Co.', 'Ltd.', 'limited', 'LIMITED',
                          'International']

    PS = PorterStemmer()
    WL = WordNetLemmatizer()
    W2N = WordsToNumbers()

    @staticmethod
    def wordAsNoun(word):
        word = word.lower()
        if word in EntityRecognition.nounList or EntityRecognition.PS.stem(word) in EntityRecognition.nounList or EntityRecognition.WL.lemmatize(word) in EntityRecognition.nounList:
            return True
        elif re.search('\d', word):
            return True
        else:
            return False
	
	
    @staticmethod
    def wordAsNumber(word):
        word = word.lower()

        if word in EntityRecognition.W2N.__ones__ or word in EntityRecognition.W2N.__tens__ or word in EntityRecognition.W2N.__groups__ or word == 'hundred':
            return True
        else:
            return False

	
	
	
    def __init__(self):
        self.raw_data = None
        self.ref_data = None
        self.tokenized_sents = []
        self.named_entity_pairs = []

    def load(self, raw_data, ref_data, tokenized_sents):
        self.raw_data = raw_data
        self.ref_data = ref_data
        self.tokenized_sents = tokenized_sents
        self.named_entity_pairs = []


    def searchEntity_Name(self):

        PrePotentialNames = set()

        for sent in self.tokenized_sents[:6]:

            if 'name' in sent.lower() or len(word_tokenize(sent)) > 5:
                words = word_tokenize(sent)
                taggedWords = pos_tag(words)
                # print taggedWords
                namedEnts = ne_chunk(taggedWords)
                # print namedEnts

                for ne in namedEnts:
                    currName = []
                    if 'PERSON' in str(ne):
                        for node in ne:
                            if not EntityRecognition.wordAsNoun(node[0]) and len(node[0]) > 2:
                                currName.append(node[0])
                        if len(currName) > 1:
                            PrePotentialNames.add(" ".join(currName))

        
        for sent in self.ref_data.split('\n'):
            if 'name ' in sent.lower():
                currName = []
                sentname = re.search('[nN][aA][mM][eE]\s.*', sent)
                words = sentname.group()[4:].strip().split()
                for i,word in enumerate(words):
                    if len(word) > 1 and word[0].isalpha() and word[0].isupper() and not EntityRecognition.wordAsNoun(word):
                        while(i<len(words) and words[i][0].isupper() and not EntityRecognition.wordAsNoun(words[i])):
                            currName.append(words[i])
                            i += 1

                        if len(currName)>0:
                            PrePotentialNames.add(" ".join(currName))

                        break

                break






        FinalNames = []

        for name in PrePotentialNames:
            FinalNames.append(["Name", name])

        return FinalNames


    def searchEntity_Date(self):

        pass

    def searchEntity_CompanyName(self):

        sents = self.ref_data.split('\n')

        PotentialCompanyName = []
        for sent in sents:
            words = sent.split()
            REVsent = []
            currName = []
            for word in words:
                if word in EntityRecognition.RefCompanyCodeList:
                    currName = [word] + currName
                    for w in REVsent:
                        if w[0] in "ABCDEFGHIJKLMNOPQRSTUVWXYZ(":
                            currName = [w] + currName

                    break
                REVsent = [word] + REVsent

            if len(currName) > 1:
                PotentialCompanyName.append(" ".join(currName))

        FinalCompanyName = []
        for cName in PotentialCompanyName:
            FinalCompanyName.append(["Company Name", cName])

        return FinalCompanyName

    def searchEntity_DateOfJoining(self):

        pass

    def searchEntity_SignotaryName(self):

        pass

    def searchEntity_AccountNo(self):

        lines = self.ref_data.split('\n')
        PotentialACCNO = []
        for sent in lines:
            words = word_tokenize(sent)
            ACC = False
            ACCword = ''
            for word in words:
                if word.lower() == 'account':
                    ACC = True
                    ACCword = word
                    break

            if ACC:
                lin = re.search(ACCword + r'.*', sent).group()
                # print ACCword, lin
                accno = re.findall('[A-Z0-9- ]{5,25}', lin)
                if len(accno) > 0  and re.search('\d', accno[0]):
                    PotentialACCNO.append(accno[0])

        for sent in self.tokenized_sents:
            words = word_tokenize(sent)
            ACC = False
            ACCword = ''
            for word in words:
                if word.lower() == 'account':
                    ACC = True
                    ACCword = word
                    break

            if ACC:
                lin = re.search(ACCword + r'.*', sent).group()
                # print ACCword, lin
                accno = re.findall('[A-Z0-9-]{5,25}', lin)
                if len(accno) > 0 and re.search('\d', accno[0]):
                    if not accno[0] in PotentialACCNO:
                        PotentialACCNO.append(accno[0])


        FinalACCNO = []
        for acc in PotentialACCNO:
            FinalACCNO.append([ 'Account No', acc ])
        return FinalACCNO


    def searchEntity_Salary(self):
        PotentialSalary = []
        lines = self.ref_data.split('\n')
        for sent in lines:
            words = word_tokenize(sent)
            salaryPresent = False

            for word in words:
                if word.lower() in EntityRecognition.CompensationKeyWords:
                    salaryPresent = True
                    # print word
                    break

            if salaryPresent:
                salAmt = re.search('\d[,.\d]+\d', sent)
                if salAmt:
                    salAmt = salAmt.group()
                    salAmt = salAmt.replace('.', ',')
                    salAmt = re.sub(',(?=\d\d$)', '.', salAmt)
                    # print '->', sent, salAmt
                    if len(salAmt) > 2 and len(re.findall('\d', salAmt)) < 10:
                        PotentialSalary.append(salAmt)
                        # else:
                        # salAmt = ''
                        # x= 0
                        # while x < len(words):
                        # if wordAsNumber(words[x]):
                        # salAmt = ''
                        # while(wordAsNumber(words[x])):
                        # salAmt = salAmt + words[x] + ' '
                        # x += 1

                        # else:
                        # x += 1

                        # if len(salAmt) > 2 and len(re.findall('\d',salAmt)) < 10:
                        # print '->', sent, salAmt
                        # PotentialSalary.append(W2N.parse(salAmt))

        for sent in self.tokenized_sents:
            words = word_tokenize(sent)
            salaryPresent = False

            # print words

            for word in words:
                if word.lower() in EntityRecognition.CompensationKeyWords:
                    salaryPresent = True
                    # print word
                    break

            if salaryPresent:
                salAmt = ''
                x = 0
                while x < len(words):
                    salAmt = ''
                    if EntityRecognition.wordAsNumber(words[x]):

                        # print words[x]
                        while (EntityRecognition.wordAsNumber(words[x]) or words[x].lower() == 'and'):
                            if not words[x].lower() == 'and':
                                salAmt = salAmt + words[x] + ' '
                            x += 1

                    else:
                        x += 1

                    # print salAmt

                    if len(salAmt) > 2 and len(re.findall('\d', salAmt)) < 10:
                        # print '->', salAmt
                        try:
                            PotentialSalary.append(str(EntityRecognition.W2N.parse(salAmt.strip())))
                        except:
                            print 'problem encountered in words to figure code.'

        FinalSalary = []
        for sal in PotentialSalary:
            FinalSalary.append(['Salary', sal])

        return FinalSalary

    def searchEntity_AddressedToHSBC(self):

        sents = self.ref_data.split('\n')
        for sent in sents:
            words = sent.split()
            for word in words:
                if word.upper() == 'HSBC':
                    return [['Address To HSBC', 'Yes']]

        return [['Address To HSBC', 'N/A']]


    def searchEntity_MetaDataSearch(self, metadata_keyword, search_reference, search_type = "numeric"):

        pass

    def searchEntity_AddressCurr(self):
        PotentialAdd = []
        sents = self.ref_data.split('\n')
        for sent_index in range(len(sents)):
            if "address" in sents[sent_index].lower():
                if "employee" in sents[sent_index].lower():
                    addressComp = " ".join(sents[sent_index].split()[3:])
                    addressComp = addressComp + " " + sents[sent_index + 1]
                else:
                    addressComp = " ".join(sents[sent_index].split()[2:])
                    addressComp = addressComp + " " + sents[sent_index + 1]
                    
                print addressComp, " <and> "
                addressComp = addressComp.replace(".", ",")
                print addressComp
                if len(addressComp.split(",")) == 4:
                    address, city, state, country = addressComp.split(",")

                    PotentialAdd.append(["Given Address", address])
                    PotentialAdd.append(["City", city])
                    PotentialAdd.append(["State", state])
                    PotentialAdd.append(["Country", country])
                    return PotentialAdd

                elif len(addressComp.split(",")) == 3:
                    address, city, country = addressComp.split(",")
                    PotentialAdd.append(["Given Address", address])
                    PotentialAdd.append(["City", city])
                    PotentialAdd.append(["Country", country])
                    return PotentialAdd

                else:
                    PotentialAdd.append(["Given Address", addressComp])
                    return PotentialAdd


        return PotentialAdd


    def searchEntity_Designation(self):
        PotentialDesg = []
        sents = self.ref_data.split('\n')
        for sent in sents:
            if "designation" in sent.lower():
                PotentialDesg.append(["Designation", " ".join(sent.split()[2:])])

        return PotentialDesg


    def getNamedEntityPairs(self):

        functionList = [self.searchEntity_Name,  self.searchEntity_Salary, self.searchEntity_AccountNo, self.searchEntity_CompanyName, self.searchEntity_AddressedToHSBC, self.searchEntity_Designation, self.searchEntity_AddressCurr]

        self.named_entity_pairs = []

        for func in functionList:

            self.named_entity_pairs.append(func())



