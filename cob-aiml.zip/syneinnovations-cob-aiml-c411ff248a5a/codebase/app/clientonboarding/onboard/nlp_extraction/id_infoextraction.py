import re
import sys
from nltk.tokenize import word_tokenize
import editdistance as edist
from pyDataPassport import NationalityDataSet, PlaceOfBirthDataSet, CountryDataSet


class id_infoextraction():

    ACCEPT_DATA = r"abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ/\\\n\t "

    PASSPORT_ENTITY_KEYWORDS = ['passport', 'name', 'given', 'surname', 'date', 'birth', 'issue', 'expiry', 'place',
                              'nation', 'mother', 'father', 'address']

    FINAL_FIELD_NAME_LIST = ['Passport No.', 'Name', 'Date Of Birth', 'Date of Issue', 'Date of Expiry', 'Nationality',
                          'Place of Birth']

    DATE_MONTH_NAME_FIELDS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']

    def RefineLine(line):

        refline = ''
        for word in line:
            if word in id_infoextraction.ACCEPT_DATA:
                refline += word
            else:
                refline += ' '

        return id_infoextraction.removeNoiseInLine(refline)

    def removeNoiseInLine(line):

        while True:
            res = re.sub('(^|\s)[^AIa ]($|\s)', '', line)
            if res == line:
                break
            else:
                line = res

        matches = re.finditer(r'(?=((^|\s)\S\S($|\s)))', line)
        results = [match.group(1) for match in matches]
        for result in results:
            result = result.strip()
            if not (result.isalpha() or result.isdigit()):
                # print result
                line = re.sub(result, '', line)

        # line = re.sub('(?=[a-zA-Z])[\\/](?=[a-zA-Z])', ' ', line)

        # print line
        if len(re.findall('\S', line)) > 3:
            return line
        else:
            return ''

    # Check if line contains Information, Based on count of capitals
    def checkInformativeField(line):
        Tcount = 0
        Ucount = 0
        for word in line:
            if word.isalpha():
                Tcount += 1
                if word.isupper():
                    Ucount += 1

        if (Ucount / float(Tcount)) >= 0.4 or re.search('\d\d\s*[A-Za-z/ ]{2,}\s*\d{2,4}', line):
            # if re.search( '\d\d\s*[A-Za-z/ ]{2,}\s*\d{2,4}', line):
            # print '-->', line, re.search( '\d\d\s*[A-Za-z/ ]{2,}\s*\d{2,4}', line).group()
            return True
        else:
            return False

    def FindEntity(line, EntityKeywords):

        prewords = word_tokenize(line)

        candidateFields = []

        for word in prewords:

            word = word.lower()
            if len(word) > 3:
                for EK in EntityKeywords:

                    if word in EK or EK in word or edist.eval(word, EK) <= min(3, (len(word) / float(3))):
                        candidateFields.append(EK)

        if len(candidateFields):
            return candidateFields
        else:
            return ['-']


    def __init__(self):

        self.raw_data = ''
        self.ref_line_data = []

        # line pairs containing field name in the first line and value in the second.
        self.candidateLinePairs = []
        # pairs containing field tags as the first item and line containing value in the second.
        self.candidateFieldValues = []
        # final pair containing field tags and value.
        self.finalisedFieldValues = []


    def load(self, raw_data, ref_line_data = None):

        self.raw_data = raw_data

        if ref_line_data is not None:
            self.ref_line_data = ref_line_data
        else:
            self.ref_line_data = []

        preprocess_data = re.sub(r'(\n)+', r'\n', self.raw_data)
        preprocess_data_lines = preprocess_data.split('\n')

        for line in preprocess_data_lines:

            refline = id_infoextraction.RefineLine(line)

            if len(refline) > 0:
                self.ref_line_data.append(refline)




    def selectCandidateLinePairs(self):

        self.candidateLinePairs = []

        for x in range(1, len(self.ref_line_data)):

            if id_infoextraction.checkInformativeField(self.ref_line_data[x]):
                self.candidateLinePairs.append([self.ref_line_data[x - 1], self.ref_line_data[x]])


    def getCandidateFieldValues(self):

        self.candidateFieldValues = []

        for pair in self.candidateLinePairs:

            fields = id_infoextraction.FindEntity(pair[0], id_infoextraction.PASSPORT_ENTITY_KEYWORDS)

            if re.search('\d\d\s*[A-Za-z/ ]{2,}\s*\d{2,4}', pair[1]) and not 'date' in fields:
                if '-' in fields:
                    fields = []
                fields.append('date')
            # print fields, pair[1]

            self.candidateFieldValues.append([fields, pair[1]])


    # TODO: finalise function to get fields.


    def getFinalisedFieldValues(self):

        self.selectCandidateLinePairs()
        self.getCandidateFieldValues()

        self.segregateNameEntities()
        self.segregatePassNoEntities()
        self.segregateNationalityEntities()
        self.segregateDateEntities()
        self.segregatePlaceEntities()
        self.segregateUnknownEntities()


    # TODO: segrgate entities required one by one


    def segregateNameEntities(self):

        nameFields = []

        for pair in self.candidateFieldValues:
            if 'mother' in pair[0]:
                nameFields.append(['Mother\'s Name', pair[1]])
            elif 'father' in pair[0]:
                nameFields.append(['Father\'s Name', pair[1]])
            elif 'surname' in pair[0]:
                nameFields.append(['Surname', pair[1]])
            elif 'name' in pair[0]:
                nameFields.append(['Name', pair[1]])

        self.finalisedFieldValues = self.finalisedFieldValues + nameFields

    def segregatePassNoEntities(self):

        passnoFields = []

        for pair in self.candidateFieldValues:
            if 'passport' in pair[0]:
                passno = re.search('\w{7}', pair[1])
                if passno:
                    if re.search('\d{3}', passno.group()):
                        passnoFields.append(['Passport No.', passno.group()])

        self.finalisedFieldValues = self.finalisedFieldValues + passnoFields

    def segregatePlaceEntities(self):

        placeFields = []

        for pair in self.candidateFieldValues:
            val = pair[1].upper()
            for place in PlaceOfBirthDataSet:

                if len(val) > 3:

                    if val in place or place in val or edist.eval(val, place) < 2:

                        if 'birth' in pair[0]:
                            placeFields.append(['Place of Birth', place.upper()])
                        elif 'auth' in pair[0]:
                            placeFields.append(['Authority Issue', place.upper()])
                        else:
                            placeFields.append(['Place', place.upper()])

        self.finalisedFieldValues = self.finalisedFieldValues + placeFields

    def segregateNationalityEntities(self):

        nationalityFields = []

        for pair in self.candidateFieldValues:
            val = pair[1].upper()
            for nationality in NationalityDataSet:
                if len(val) > 3:

                    if 'nation' in pair[0] and edist.eval(val, nationality) < 2:
                        nationalityFields.append(['Nationality', nationality])

        if len(nationalityFields):
            return nationalityFields

        for pair in self.candidateFieldValues:
            val = pair[1].upper()
            for nationality in NationalityDataSet:

                if len(val) > 3:

                    if val in nationality or nationality in val:
                        nationalityFields.append(['Nationality', nationality])

                    if 'nation' in pair[0] and edist.eval(val, nationality) < 2:
                        nationalityFields.append(['Nationality', nationality])

        self.finalisedFieldValues = self.finalisedFieldValues + nationalityFields

    def segregateUnknownEntities(self):

        UnknownField = []
        for pair in self.candidateFieldValues:
            if '-' in pair[0]:
                UnknownField.append(['Unknown Field', pair[1]])

        self.finalisedFieldValues = self.finalisedFieldValues + UnknownField

    def segregateDateEntities(self):

        dateFields = []
        unsorteddateFields = []

        for pair in self.candidateFieldValues:

            potentialDate = re.search('\d\d\s*[A-Za-z/ ]{2,}\s*\d{2,4}', pair[1])

            if potentialDate:

                day = re.search('\d\d', potentialDate.group()).group()
                month = re.search('(?<=\d{2})[A-Za-z/ ]*', potentialDate.group()).group()
                year = re.search('\d{2,4}\s*$', potentialDate.group()).group()
                breakLoop = False
                for m in id_infoextraction.DATE_MONTH_NAME_FIELDS:
                    for mt in month.split():
                        mt = mt.upper()
                        if len(mt) > 2 and (m in mt or edist.eval(mt, m) <= 1):
                            breakLoop = True  # print month, m , mt
                            month = m
                            # print '-->', month, m, mt
                            break
                    if breakLoop:
                        break
                if month in id_infoextraction.DATE_MONTH_NAME_FIELDS:
                    if 'birth' in pair[0]:
                        dateFields.append([1, [day, month, year]])
                    elif 'issue' in pair[0]:
                        dateFields.append([2, [day, month, year]])
                    elif 'expiry' in pair[0]:
                        dateFields.append([3, [day, month, year]])
                    else:
                        # print [day, month, year]
                        unsorteddateFields.append([day, month, year])

        # dateFields = sorted(dateFields)

        for date in unsorteddateFields:
            dateYY = re.search('\d\d$', date[2])
            if dateYY:
                dateYY = int(dateYY.group())
                if dateYY > 50:
                    dateFields.append([1, date])
                elif dateYY < 17:
                    dateFields.append([2, date])
                elif dateYY >= 17:
                    dateFields.append([3, date])


                    # for date in unsorteddateFields:
                    # pushed = False
                    # for dateS in dateFields:

                    # if int(date[2]) < int(dateS[1][2]):

                    # dateFields.append([dateS[0] - 1, date])
                    # pushed = True

                    # if not pushed:

                    # dateFields.append([3, date])

        # dateFields = sorted(dateFields)

        finalDateFields = []
        for date in dateFields:
            if date[0] == 1:
                # if (int(date[1][2]) < 2000 and int(date[1][2]) > 1950) or (int(date[1][2]) < 100 and int(date[1][2]) > 50):
                finalDateFields.append(['Date of Birth', date[1][0] + ' ' + date[1][1] + ' ' + date[1][2]])
            if date[0] == 2:
                finalDateFields.append(['Date of Issue', date[1][0] + ' ' + date[1][1] + ' ' + date[1][2]])
            if date[0] == 3:
                finalDateFields.append(['Date of Expiry', date[1][0] + ' ' + date[1][1] + ' ' + date[1][2]])

        self.finalisedFieldValues = self.finalisedFieldValues + finalDateFields

