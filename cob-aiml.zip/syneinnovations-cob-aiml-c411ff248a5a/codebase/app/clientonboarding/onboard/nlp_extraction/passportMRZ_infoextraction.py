import re
import sys


class passport_MRZ_infoExtraction():

    COUNTRY_CODES_DATA = open('prerequisiteData/PPDataCountryCode.txt', 'r').read().split('\n')
    COUNTRY_CODES = {}
    MULT_ARR_PP_NO = [7,3,1]
    ALPH_MAP_PP_NO = {'<' : 0, '1' : 1, '2' : 2, '3' : 3, '4' : 4, '5' : 5, '6' : 6, '7' : 7, '8' : 8, '9' : 9, '0' : 0, 'A' : 10, 'B' : 11, 'C' : 12, 'D' : 13, 'E' : 14, 'F' : 15, 'G' : 16, 'H' : 17, 'I' : 18, 'J' : 19, 'K' : 20, 'L' : 21, 'M' : 22, 'N' : 23, 'O' : 24, 'P' : 25, 'Q' : 26, 'R' : 27, 'S' : 28, 'T' : 29, 'U' : 30, 'V' : 31, 'W' : 32, 'X' : 33, 'Y' : 34, 'Z' : 35 }
    MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    
    def __init__(self):

        self.raw_data = ""
        self.extracted_data = []
        for x in passport_MRZ_infoExtraction.COUNTRY_CODES_DATA:
            key, value = x.split('=')
            passport_MRZ_infoExtraction.COUNTRY_CODES[key] = value


    def preProcessData(self, raw_data):

        self.raw_data = raw_data
        self.LastLines = re.search(r'[A-Z]<(.|(\n))+\d', self.raw_data)
        if self.LastLines is not None:
            print self.LastLines.group()

            # fileWritePath = 'uploads/TempOCR_result.txt'
            # fileWriteDoc = open(fileWritePath, 'w')
            # fileWriteDoc.write(self.raw_data)
            # fileWriteDoc.close()
        else:
            print 'last lines not found'

    def EvaluateDateExpression(self, date):
        yy, mm, dd = date[0:2], date[2:4], date[4:6]
        if int(mm) < 13:
            mm = passport_MRZ_infoExtraction.MONTHS[int(mm) - 1]
        else:
            return ''

        if int(dd) > 31:
            return ''

        return dd + ' / ' + mm + ' / ' + yy

    def CheckDigitVerification(self, stringVal, checkDigit):

        if checkDigit.isdigit():
            checkDigit = int(checkDigit)
        else:
            return False

        checkSum = 0
        for x in range(len(stringVal)):
            if stringVal[x] in passport_MRZ_infoExtraction.ALPH_MAP_PP_NO:
                checkSum += passport_MRZ_infoExtraction.ALPH_MAP_PP_NO[stringVal[x]] * passport_MRZ_infoExtraction.MULT_ARR_PP_NO[x % 3]

        if checkSum % 10 == checkDigit:
            return True
        else:
            return False

    def extLastLineOne(self):

        # self.extracted_data = []
        if self.LastLines:
            LastLines = self.LastLines.group()
            LastLines = LastLines.replace(' ', '')

            NameAndAuthEntities = []
            firstLine = LastLines.split('\n')[0]

            firstLine = firstLine.replace('1', 'I')
            firstLine = firstLine.replace('2', 'Z')
            firstLine = firstLine.replace('4', 'A')
            firstLine = firstLine.replace('5', 'S')
            firstLine = firstLine.replace('8', 'B')
            firstLine = firstLine.replace('0', 'O')

            NameValue = ''
            AuthValue = ''
            if re.search('^P<', LastLines):
                self.extracted_data.append(['DocumentType','Passport'])
                
                # Process First Line:
            elif re.search('^S<', LastLines):
                self.extracted_data.append(['DocumentType','Seafarer\'s Passport'])

            elif re.search('^V<', LastLines):
                self.extracted_data.append(['DocumentType','Visa'])



            NameAndAuthEntities = re.findall(r'(?<=<)[A-Za-z]+(?=<)', firstLine)


            if len(NameAndAuthEntities) > 0:
                if NameAndAuthEntities[0][0:3] in passport_MRZ_infoExtraction.COUNTRY_CODES:
                    for Ent in NameAndAuthEntities[1:]:
                        if len(Ent) > 1:
                            NameValue = NameValue + Ent + ' '
                    AuthValue = passport_MRZ_infoExtraction.COUNTRY_CODES[NameAndAuthEntities[0][0:3]]
                    NameValue = NameValue + NameAndAuthEntities[0][3:]
                elif NameAndAuthEntities[0] == 'D':
                    AuthValue = 'Germany'
                    for Ent in NameAndAuthEntities[1:]:
                        NameValue = NameValue + Ent + ' '
            if len(NameValue):
                self.extracted_data.append(["Person's Name",NameValue])
            if len(AuthValue):
                self.extracted_data.append(['Issuing Country/Organisation' , AuthValue])



    def extLastLineTwo(self):

        if self.LastLines:
            LastLines = self.LastLines.group()
            LastLines = LastLines.replace(' ', '')

            # print 'At line 2 : '
            # print LastLines

            if '\n' in LastLines:
                secondLine = LastLines.split('\n')[1]
                if len(secondLine) < 5:
                    secondLine = LastLines.split('\n')[-1]

                # TODO: Process second line of MRZ

                # Get Passport Number:

                PassportNo = re.search('^[\dA-Z]{6}[\d<]{2,6}(?=[A-Z])', secondLine)
                PassportNoCheckDigitVerification = False
                if PassportNo:
                    PassportNo = PassportNo.group()
                    PassportNo, CheckDigit = PassportNo[:-1].replace('<', ''), PassportNo[-1]
                    self.extracted_data.append(['Passport Number', PassportNo])
                    if self.CheckDigitVerification(PassportNo, CheckDigit):
                        self.extracted_data.append(['Passport No CD Verification','Accepted'])
                    else:
                        self.extracted_data.append(['Passport No CD Verification','Unaccepted'])

                # Get Nationality

                NationalitySrch = re.search('(?<=\d)[A-Z]{3}(?=\d)', secondLine)
                NationalityValue = ''
                if NationalitySrch:
                    Nationality = NationalitySrch.group()
                    if Nationality in passport_MRZ_infoExtraction.COUNTRY_CODES:
                        NationalityValue = passport_MRZ_infoExtraction.COUNTRY_CODES[Nationality]

                if len(NationalityValue) > 0:
                    self.extracted_data.append(['Nationality' , NationalityValue])

                # Get Date of Birth
                if NationalitySrch:
                    DOBsrch = re.search('(?<=' + Nationality + r')\d{7}(?=[MFHE<])', secondLine)
                else:
                    DOBsrch = re.search('(?<=[A-Z])\d{7}(?=[MF<])', secondLine)

                if DOBsrch:
                    DOB, CheckDigitDOB = DOBsrch.group()[:-1], DOBsrch.group()[-1]
                    DOBValue = self.EvaluateDateExpression(DOB)
                    if DOBValue is not None and len(DOBValue):
                        self.extracted_data.append(['Date of Birth', DOBValue])
                        if self.CheckDigitVerification(DOB, CheckDigitDOB):
                            self.extracted_data.append(['DOB CD Verification','Accepted'])
                        else:
                            self.extracted_data.append(['DOB CD Verification','Unaccepted'])

                # Get gender
                GenderSrch = re.search('(?<=\d)[MFHE](?=\d{7})', secondLine)
                GenderSrchLL = re.search('(?<=\d)[MFHE](?=\d)', secondLine)
                Gender = None
                if GenderSrch:
                    Gender = GenderSrch.group()
                elif GenderSrchLL:
                    Gender = GenderSrchLL.group()

                if Gender:
                    if Gender == 'M' or Gender == 'H' or Gender == 'E':
                        self.extracted_data.append(['Sex','Male'])
                    elif Gender == 'F':
                        self.extracted_data.append(['Sex','Female'])

                # Get Date of Expiry
                if Gender:
                    DOExpSrch = re.search(r'(?<=' + Gender + r')\d{7}', secondLine)
                    if DOExpSrch:
                        DOExp, CheckDigitDOExp = DOExpSrch.group()[:-1], DOExpSrch.group()[-1]
                        DOExpValue = self.EvaluateDateExpression(DOExp)
                        if DOExpValue is not None and len(DOExpValue):
                            self.extracted_data.append(['Date of Expiry', DOExpValue])
                            if self.CheckDigitVerification(DOExp, CheckDigitDOExp):
                                self.extracted_data.append(['Date of Expiry CD Verification', 'Accepted'])
                            else:
                                self.extracted_data.append(['Date of Expiry CD Verification', 'Unaccepted'])


    def extLastLine(self):

        self.extracted_data = []
        self.extLastLineOne()
        self.extLastLineTwo()


    def getResult(self):

        self.extLastLine()
        return self.extracted_data

    def getResultDict(self):

        FinalDict = {}
        self.extLastLine()
        if self.extracted_data is not None and len(self.extracted_data) > 0:
            for key,value in self.extracted_data:
                if key not in FinalDict:
                    FinalDict[key] = value

        return FinalDict

