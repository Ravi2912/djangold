# Data for passport documents.


NationalityDataList = open('prerequisiteData/preNationalityData.txt', 'r').read().split('\n')
NationalityDataSet = {val : 1 for val in NationalityDataList}

PlaceOfBirthDataList = open('prerequisiteData/CityPlaceData.txt', 'r').read().split('\n')
PlaceOfBirthDataSet = {val : 1 for val in PlaceOfBirthDataList}

CountryDataList = open('prerequisiteData/CountryData.txt', 'r').read().split('\n')
CountryDataSet = {val : 1 for val in CountryDataList}