import re
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk import pos_tag, ne_chunk
from nltk.stem import PorterStemmer, WordNetLemmatizer
import sys
from words2num import WordsToNumbers
from entity_recognition import EntityRecognition
from clause_detection import ClauseDetection


class TextExtraction():


    #
    # def __init__(self):
    #     pass

    ACCEPT_CHAR_DATA = r'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'
    ACCEPT_SPECIAL_CHAR_DATA = '\n\t!?.$*():;+=-\'", '



    def __init__(self, raw_data = ""):
        self.raw_data = raw_data
        self.ref_data = ""
        self.tokenized_sents = []
        self.m_obj_EntityRecognition = EntityRecognition()
        self.m_obj_ClauseDetection = ClauseDetection()


    def preProcessData(self, raw_data = None):

        if raw_data is not None:
            self.raw_data = raw_data

            # print raw data in a file:

            # fileWritePath = 'uploads/TempOCR_result.txt'
            # fileWriteDoc = open(fileWritePath, 'w')
            # fileWriteDoc.write(self.raw_data)
            # fileWriteDoc.close()



        self.ref_data = ''
        self.tokenized_sents = []

        # print self.raw_data

        # self.raw_data = self.raw_data.replace('', 'fi')

        for data in self.raw_data:

            if data in TextExtraction.ACCEPT_CHAR_DATA or data in TextExtraction.ACCEPT_SPECIAL_CHAR_DATA:
                self.ref_data = self.ref_data + data

        self.tokenized_sents = sent_tokenize(self.ref_data)

        self.m_obj_EntityRecognition.load(self.raw_data, self.ref_data, self.tokenized_sents)
        self.m_obj_ClauseDetection.load(self.raw_data, self.ref_data)

    def getResult(self):
        Result_Fields = []
        Result_Clauses = []
        self.m_obj_EntityRecognition.getNamedEntityPairs()
        Result_Fields = self.m_obj_EntityRecognition.named_entity_pairs
        self.m_obj_ClauseDetection.getClauseAnalysis()
        Result_Clauses = self.m_obj_ClauseDetection.ClauseAnalysis

        # except:
        # print "object data not defined."
        FinalResults = []
        for er in Result_Fields:
            for erk in er:
                if len(erk)>1:
                    FinalResults.append(erk) # [0] + '\t:\t' + erk[1] + '\n'

        for cl in Result_Clauses:
                 if len(cl)>1:
                     FinalResults.append(cl) # [0] + '\t:\t' + cl[1] + '\n'

        return FinalResults


    def getResultDict(self):

        Result_Fields = []
        Result_Clauses = []
        self.m_obj_EntityRecognition.getNamedEntityPairs()
        Result_Fields = self.m_obj_EntityRecognition.named_entity_pairs
        self.m_obj_ClauseDetection.getClauseAnalysis()
        Result_Clauses = self.m_obj_ClauseDetection.ClauseAnalysis

        FinalResults = {}
        for er in Result_Fields:
            try:
                for erk in er:
                    if len(erk)>1 and erk[0] not in FinalResults:
                        FinalResults[erk[0]] = erk[1] # [0] + '\t:\t' + erk[1] + '\n'
            except:
                print "NonetypeObject here"

        for cl in Result_Clauses:
                 if len(cl)>1 and cl[0] not in cl[1]:
                     FinalResults[cl[0]] = cl[1] # [0] + '\t:\t' + cl[1] + '\n'

        return FinalResults
