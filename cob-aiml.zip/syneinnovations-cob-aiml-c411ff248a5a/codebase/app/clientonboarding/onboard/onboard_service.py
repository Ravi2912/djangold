from onboard.mongo import MongoConnector
from image_processing import mserImageCrop, DocOcr, base64Image
from nlp_extraction import TextExtraction, passport_MRZ_infoExtraction

# Define Image Processing and Nlp Class Objects :
obj_mserImageCrop = mserImageCrop()

obj_DocOcr = DocOcr()

obj_DocNLP = TextExtraction()

obj_IdNLP = passport_MRZ_infoExtraction()

obj_bas64Image = base64Image()


class OnboardService:
    def create_customer(self, db_name):
        collection_name = 'Identity'
        query = '{}'
        doc = {}
        response = {}
        customer_id = OnboardService().get_max_customer(db_name, collection_name, query)
        doc['customerId'] = int(customer_id) + 1
        OnboardService().store_data(db_name, collection_name, doc)
        response['customerId'] = doc['customerId']
        return response

    # doc contains json data to be stored in collection.
    def store_data(self, db_name, collection_name, doc):
        connection = MongoConnector.get_connection(db_name, collection_name);
        customer_id = int(doc['customerId'])
        cursor = connection.find({'customerId':customer_id}).sort('customerId', -1).limit(1)
        if cursor.count() > 0:
            doc['_id'] = cursor.next()['_id']
            connection.update_one({'customerId':customer_id}, {'$set':doc}, True)
        else:
            connection.insert(doc)
            del doc['_id']
        return doc

    # Query should contain json formatted data for where clause
    def get_records(self, db_name, collection_name, query):
        connection = MongoConnector.get_connection(db_name, collection_name);
        return connection.find(query);

    # Query should contain json formatted data for where clause
    def get_max_customer(self, db_name, collection_name, query):
        connection = MongoConnector.get_connection(db_name, collection_name);
        identity_cursor = connection.find().sort('customerId', -1).limit(1)
        if identity_cursor.count() > 0:
            identity_doc = identity_cursor.next()
            if 'customerId' in identity_doc:
                return identity_doc['customerId'];
        return 0

    @staticmethod
    def getKeyListOrder(keyDict, doc_type):

        keyList_Iddoc = ["DocumentType", "Person's Name", "Passport Number", "Issuing Country/Organisation",
                         "Nationality", "Date of Birth", "Sex", "Passport No CD Verification"]
        keyList_SalDoc = ["Name", "Salary", "Company Name", "Account No", "Given Address", "City", "State", "Country",
                          "Designation", "Salary Transfer Clause", "Clearance Letter Clause", "Notification Clause",
                          "End of Benefits Clause"]

        FinalKeyDict = []
        if doc_type == "id_proof":
            for key in keyList_Iddoc:
                if key in keyDict:
                    FinalKeyDict.append(key)


        elif doc_type == "salary_proof":
            for key in keyList_SalDoc:
                if key in keyDict:
                    FinalKeyDict.append(key)

        return FinalKeyDict

    def perform_ocr(self, file_data, documentType):

        # TODO: documentType should be either "salary_proof" or "id_proof"

        # Naunidh's code call
        obj_bas64Image.convert2CV_Image(file_data)
        obj_mserImageCrop.loadImg(obj_bas64Image.cv_Image)
        obj_mserImageCrop.cropImage()

        if documentType == 'salary_proof':
            obj_DocOcr.load(obj_mserImageCrop.croppedImage, obj_mserImageCrop.croppedGrayImage)
            obj_DocOcr.runGrayImageOCR()
            obj_DocNLP.preProcessData(obj_DocOcr.grayOCR_result)
            ALLoutput = obj_DocNLP.getResultDict()
            ALLoutput["InputImageHeight"] = obj_mserImageCrop.Height
            ALLoutput["InputImageWidth"] = obj_mserImageCrop.Width
            ALLoutput["keywordOrder"] = OnboardService.getKeyListOrder(ALLoutput, documentType)
            ALLoutput["idImage"] = ""
            ALLoutput["idImageType"] = "PNG"
            ALLoutput["idImageHeight"] = 0
            ALLoutput["idImageWidth"] = 0

        elif documentType == 'id_proof':
            obj_mserImageCrop.halfImage()
            obj_mserImageCrop.iddocMrzSectionProcess()
            obj_DocOcr.load(obj_mserImageCrop.croppedImage, obj_mserImageCrop.croppedGrayImage)
            obj_DocOcr.runGrayImageOCR()
            # print obj_DocOcr.grayOCR_result
            obj_IdNLP.preProcessData(obj_DocOcr.grayOCR_result)
            ALLoutput = obj_IdNLP.getResultDict()
            ALLoutput["keywordOrder"] = OnboardService.getKeyListOrder(ALLoutput, "id_proof")
            ALLoutput["InputImageHeight"] = obj_mserImageCrop.Height
            ALLoutput["InputImageWidth"] = obj_mserImageCrop.Width
            obj_mserImageCrop.scanIdImage()
            ALLoutput["idImage"] = 'data:image/png;base64,' + obj_bas64Image.convertCV_Image2Base64(
                obj_mserImageCrop.idPhotoImage)
            ALLoutput["idImageType"] = "PNG"
            ALLoutput["idImageHeight"] = obj_mserImageCrop.idPhotoImage.shape[0]
            ALLoutput["idImageWidth"] = obj_mserImageCrop.idPhotoImage.shape[1]

        # print NLPoutput
        # NLPoutput = {'Name': ['Zara'], 'Age': [8, 7], 'Class': ['First']}
        # data = {}
        # for key in ALLoutput:
        #     print ALLoutput[key]
        # print data
        return ALLoutput

    def retrieve_form_data(self, customer_id, db_name, collection_name_salary, collection_name_identity):
        form_data = {}
        form_data = OnboardService().fetch_details(db_name, collection_name_salary, form_data, customer_id)
        form_data = OnboardService().fetch_details(db_name, collection_name_identity, form_data, customer_id)
        del form_data['_id']
        return form_data

    # Get details
    def fetch_details(self, db_name, collection_name, form_data, customer_id):
        connection_sal = MongoConnector.get_connection(db_name, collection_name)
        query = {"customerId": customer_id}
        sal_cursor = connection_sal.find(query)
        if sal_cursor.count() > 0:
            salary_data = sal_cursor.next()
            for key, value in salary_data.items():
                form_data[key] = value
        return form_data
