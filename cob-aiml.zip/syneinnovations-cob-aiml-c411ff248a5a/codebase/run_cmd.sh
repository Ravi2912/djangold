yum repolist
yum install mongodb-org -y
mongod --fork --logpath /home/mongo_log
cd /home/app/clientonboarding
nohup python manage.py runserver 0.0.0.0:5000 &
/opt/tomcat/bin/catalina.sh run
